_N_E = (window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
  [46],
  {
    0: function (e, t, r) {
      r("ZHK4"), (e.exports = r("7xIC"));
    },
    IlR1: function (e, t, r) {
      "use strict";
      r.r(t);
      var n = r("jg1C"),
        o = r("LHL8"),
        c = (r("LNcM"), r("6/RC")),
        i = r("LaGA");
      c.canUseDOM &&
        (window.ResizeObserver || (window.ResizeObserver = i.a),
        (window.PolyfillResizeObserver = window.ResizeObserver));
      var s = r("ERkP"),
        p = r.n(s),
        a = r("vpUC"),
        w = r.n(a);
      function O(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          t &&
            (n = n.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            r.push.apply(r, n);
        }
        return r;
      }
      function b(e) {
        for (var t = 1; t < arguments.length; t++) {
          var r = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? O(Object(r), !0).forEach(function (t) {
                Object(o.a)(e, t, r[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
            : O(Object(r)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(r, t)
                );
              });
        }
        return e;
      }
      t.default = function (e) {
        var t = e.Component,
          r = e.pageProps;
        return Object(n.jsxs)(p.a.Fragment, {
          children: [
            Object(n.jsx)(w.a, {
              children: Object(n.jsx)("meta", {
                content: "width=device-width, initial-scale=1",
                name: "viewport",
              }),
            }),
            Object(n.jsx)(t, b({}, r)),
          ],
        });
      };
    },
    ZHK4: function (e, t, r) {
      (window.__NEXT_P = window.__NEXT_P || []).push([
        "/_app",
        function () {
          return r("IlR1");
        },
      ]);
    },
  },
  [[0, 6, 5]],
]);
