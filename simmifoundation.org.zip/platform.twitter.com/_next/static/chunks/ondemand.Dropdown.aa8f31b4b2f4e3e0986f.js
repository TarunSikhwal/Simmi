(window.webpackJsonp_N_E = window.webpackJsonp_N_E || []).push([
  [44],
  {
    fyKl: function (e, t, n) {
      "use strict";
      n.r(t),
        n.d(t, "default", function () {
          return L;
        });
      var o = n("jg1C"),
        r = n("2In8"),
        i = n("Alxx"),
        c = n("aNP4"),
        a = n("UFnO"),
        s = n("i3ax"),
        d = n("whUO"),
        l = n("LHL8"),
        u = n("ERkP"),
        p = n.n(u),
        f = n("jdj2"),
        h = n.n(f),
        b = n("/uF9"),
        O = n.n(b),
        j = n("3xO4"),
        m = n.n(j),
        v = n("VY6S"),
        w = n("zfvc"),
        y = n("jHwr"),
        _ = n("5tB6"),
        g = n("9Xa1"),
        x = n("//dC"),
        R = n("lHOd"),
        N = n("Oe3h"),
        H = n("0FVZ"),
        D = n("7N4s"),
        C = n("cHvH"),
        P = n("rHpw");
      function F(e) {
        var t = (function () {
          if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
          if (Reflect.construct.sham) return !1;
          if ("function" === typeof Proxy) return !0;
          try {
            return (
              Date.prototype.toString.call(
                Reflect.construct(Date, [], function () {})
              ),
              !0
            );
          } catch (e) {
            return !1;
          }
        })();
        return function () {
          var n,
            o = Object(d.a)(e);
          if (t) {
            var r = Object(d.a)(this).constructor;
            n = Reflect.construct(o, arguments, r);
          } else n = o.apply(this, arguments);
          return Object(s.a)(this, n);
        };
      }
      function k(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var o = Object.getOwnPropertySymbols(e);
          t &&
            (o = o.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            n.push.apply(n, o);
        }
        return n;
      }
      function U(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? k(Object(n), !0).forEach(function (t) {
                Object(l.a)(e, t, n[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : k(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t)
                );
              });
        }
        return e;
      }
      var E = P.a.create(function (e) {
          return {
            rootNarrow: { maxWidth: "75%" },
            rootWide: { maxWidth: "calc(".concat(e.spaces.space64, " * 6)") },
            anchor: P.a.absoluteFillObject,
            mask: U(U({}, P.a.absoluteFillObject), {}, { position: "fixed" }),
            bodyRectHelper: U(
              U({}, P.a.absoluteFillObject),
              {},
              { bottom: void 0 }
            ),
            content: {
              borderRadius: e.borderRadii.small,
              position: "absolute",
              overflow: "hidden",
              backgroundColor: e.colors.navigationBackground,
              boxShadow: e.boxShadows.medium,
            },
            contentInitialRender: { position: "fixed", opacity: 0 },
            contentFixed: {
              position: "fixed",
              overflowY: "auto",
              overscrollBehavior: "contain",
            },
          };
        }),
        L = (function (e) {
          Object(a.a)(n, e);
          var t = F(n);
          function n(e, o) {
            var i;
            return (
              Object(r.a)(this, n),
              (i = t.call(this, e, o)),
              Object(l.a)(
                Object(c.a)(i),
                "_handleAnimateComplete",
                function () {
                  var e = i.props.onAnimateComplete;
                  e && e();
                }
              ),
              Object(l.a)(Object(c.a)(i), "_handleEsc", function (e) {
                var t = i.props.onDismiss,
                  n = e.altKey,
                  o = e.ctrlKey,
                  r = e.key,
                  c = e.metaKey;
                !(n || o || c) && "Escape" === r && t();
              }),
              Object(l.a)(
                Object(c.a)(i),
                "_receiveBodyRectHelperRef",
                function (e) {
                  e &&
                    i._bodyRectHelperNode !== e &&
                    ((i._bodyRectHelperNode = e), i._scheduleUpdate());
                }
              ),
              Object(l.a)(Object(c.a)(i), "_receiveAnchorRef", function (e) {
                e &&
                  i._anchorNode !== e &&
                  ((i._anchorNode = e), i._scheduleUpdate());
              }),
              Object(l.a)(Object(c.a)(i), "_receiveContentRef", function (e) {
                e &&
                  i._contentNode !== e &&
                  ((i._contentNode = e), i._scheduleUpdate());
              }),
              Object(l.a)(Object(c.a)(i), "_updatePosition", function () {
                if (
                  i._mounted &&
                  (i._anchorNode || i.props.position) &&
                  i._contentNode &&
                  i._contentNode instanceof window.HTMLElement &&
                  i._bodyRectHelperNode &&
                  i._bodyRectHelperNode instanceof window.HTMLElement
                ) {
                  var e = i._contentNode.scrollHeight,
                    t = i._contentNode.scrollWidth,
                    n = i._bodyRectHelperNode.getBoundingClientRect(),
                    o = n.left,
                    r = n.top,
                    c = n.width,
                    a = h.a.get("window"),
                    s = a.height,
                    d = a.width,
                    l = { left: 0, top: 0, height: 0, width: 0 };
                  i.props.position
                    ? (l = U(U({}, l), i.props.position))
                    : i._anchorNode &&
                      i._anchorNode instanceof window.HTMLElement &&
                      (l = i._anchorNode.getBoundingClientRect());
                  var u = l,
                    p = u.height,
                    f = u.left,
                    b = u.top,
                    j = u.width,
                    m = d - c,
                    v = f - o,
                    w = b - r,
                    y = f + j >= t,
                    _ = b + p >= e,
                    g = d - f >= t,
                    x = s - b >= e,
                    R = i.props.preferredVerticalOrientation,
                    N = (function (e) {
                      return O.a.getConstants().isRTL
                        ? "left" === e
                          ? "right"
                          : "left"
                        : e;
                    })(i.props.preferredHorizontalOrientation),
                    H =
                      i.state.verticalOrientation ||
                      (function (e) {
                        var t = e.canOrientDown,
                          n = e.canOrientUp,
                          o = e.verticalPreference;
                        return (n && t) || (!n && !t) ? o : n ? "up" : "down";
                      })({
                        verticalPreference: R,
                        canOrientUp: _,
                        canOrientDown: x,
                      }),
                    D =
                      i.state.horizontalOrientation ||
                      (function (e) {
                        var t = e.canOrientLeft,
                          n = e.canOrientRight,
                          o = e.horizontalPreference;
                        return !t || ("left" !== o && n) ? "right" : "left";
                      })({
                        horizontalPreference: N,
                        canOrientLeft: y,
                        canOrientRight: g,
                      }),
                    C = i.props.isFixed ? f : v,
                    P = i.props.isFixed ? b : w,
                    F = "up" === H ? P + p - e : P,
                    k = "left" === D ? d - C - j - m : d - C - t - m;
                  i.setState({
                    top: Math.max(F, 0),
                    right: k,
                    verticalOrientation: H,
                    horizontalOrientation: D,
                  });
                }
              }),
              (i.state = Object.freeze({})),
              (i._scheduleUpdate = Object(y.a)(
                i._updatePosition,
                window.requestAnimationFrame
              )),
              (i._scheduleDebouncedUpdate = Object(v.a)(
                i._scheduleUpdate,
                250
              )),
              i
            );
          }
          return (
            Object(i.a)(n, [
              {
                key: "componentDidMount",
                value: function () {
                  (this._mounted = !0),
                    h.a.addEventListener(
                      "change",
                      this._scheduleDebouncedUpdate
                    );
                },
              },
              {
                key: "componentWillUnmount",
                value: function () {
                  (this._mounted = !1),
                    h.a.removeEventListener(
                      "change",
                      this._scheduleDebouncedUpdate
                    );
                },
              },
              {
                key: "render",
                value: function () {
                  var e = this,
                    t = this.props,
                    n = t.animateInDuration,
                    r = t.animateType,
                    i = t.children,
                    c = t.isFixed,
                    a = t.onDismiss,
                    s = t.preventFocusShift,
                    d = t.withKeyboardNavigation,
                    l = this.state,
                    u = l.right,
                    f = l.top,
                    h = l.verticalOrientation,
                    b = void 0 === f,
                    j = d ? _.a : p.a.Fragment,
                    v = "calc(100vh - ".concat(f || 0, "px)"),
                    y = [
                      E.content,
                      b && E.contentInitialRender,
                      c && [E.contentFixed, { maxHeight: v }],
                      {
                        top: f,
                        end: O.a.getConstants().isRTL ? void 0 : u,
                        start: O.a.getConstants().isRTL ? u : void 0,
                      },
                    ],
                    F = Object(o.jsxs)(p.a.Fragment, {
                      children: [
                        Object(o.jsx)(m.a, { onClick: a, style: E.mask }),
                        Object(o.jsx)(m.a, {
                          ref: this._receiveBodyRectHelperRef,
                          style: E.bodyRectHelper,
                        }),
                        Object(o.jsx)(C.a, {
                          children: function (t) {
                            var c = t.windowWidth;
                            return Object(o.jsx)(m.a, {
                              accessibilityRole: "menu",
                              onKeyUp: e._handleEsc,
                              ref: e._receiveContentRef,
                              style: [
                                c < P.a.theme.breakpoints.medium
                                  ? E.rootNarrow
                                  : E.rootWide,
                                y,
                              ],
                              children:
                                b && "slide" === r
                                  ? i
                                  : Object(o.jsx)(w.a, {
                                      animateMount: "up" !== h,
                                      duration: n,
                                      onAnimateComplete:
                                        e._handleAnimateComplete,
                                      show: !0,
                                      type: r,
                                      children: function (e) {
                                        var t = e.isAnimating;
                                        return Object(o.jsx)(N.a, {
                                          id: "Dropdown",
                                          minimizeReporting: t,
                                          children: function (e, t) {
                                            return Object(o.jsx)(
                                              m.a,
                                              U(
                                                U({ ref: e() }, t({})),
                                                {},
                                                { children: i }
                                              )
                                            );
                                          },
                                        });
                                      },
                                    }),
                            });
                          },
                        }),
                      ],
                    });
                  return Object(o.jsx)(m.a, {
                    ref: this._receiveAnchorRef,
                    style: E.anchor,
                    children: Object(o.jsx)(H.a.Dropdown, {
                      children: Object(o.jsx)(R.a.Consumer, {
                        children: function (e) {
                          return Object(o.jsx)(D.b.Consumer, {
                            children: function (t) {
                              var n = t.isModal;
                              return Object(o.jsx)(x.a, {
                                history: e,
                                isModal: n,
                                onDismiss: a,
                                children: s
                                  ? F
                                  : Object(o.jsx)(g.a, {
                                      children: Object(o.jsx)(j, {
                                        children: F,
                                      }),
                                    }),
                              });
                            },
                          });
                        },
                      }),
                    }),
                  });
                },
              },
            ]),
            n
          );
        })(p.a.Component);
      Object(l.a)(L, "defaultProps", {
        preferredHorizontalOrientation: "left",
        preferredVerticalOrientation: "down",
        animateType: "slide",
        animateInDuration: "normal",
        withKeyboardNavigation: !0,
      });
    },
    jHwr: function (e, t, n) {
      "use strict";
      t.a = function (e, t) {
        var n = null,
          o = function () {
            (n = null), e();
          };
        return function () {
          return n || (n = t(o)), n;
        };
      };
    },
  },
]);
