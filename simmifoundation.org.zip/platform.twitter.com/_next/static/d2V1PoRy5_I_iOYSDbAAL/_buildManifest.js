self.__BUILD_MANIFEST = {
  __rewrites: { beforeFiles: [], afterFiles: [], fallback: [] },
  "/": ["static\u002Fchunks\u002Fpages\u002Findex-4203db594ddb7993dc42.js"],
  "/_error": [
    "static\u002Fchunks\u002Fpages\u002F_error-3831da6237804da71418.js",
  ],
  "/timeline-list/list-id/[listId]": [
    "static\u002Fchunks\u002Fpages\u002Ftimeline-list\u002Flist-id\u002F[listId]-53bae986e04cc99f0fc8.js",
  ],
  "/timeline-list/screen-name/[screenName]/slug/[slug]": [
    "static\u002Fchunks\u002Fpages\u002Ftimeline-list\u002Fscreen-name\u002F[screenName]\u002Fslug\u002F[slug]-0cd847ce6302e08e0c0b.js",
  ],
  "/timeline-profile/screen-name/[screenName]": [
    "static\u002Fchunks\u002Fpages\u002Ftimeline-profile\u002Fscreen-name\u002F[screenName]-c8b4c96951cf24f547b4.js",
  ],
  "/timeline-profile/user-id/[userId]": [
    "static\u002Fchunks\u002Fpages\u002Ftimeline-profile\u002Fuser-id\u002F[userId]-879461ef988388f8a974.js",
  ],
  sortedPages: [
    "\u002F",
    "\u002F_app",
    "\u002F_error",
    "\u002Ftimeline-list\u002Flist-id\u002F[listId]",
    "\u002Ftimeline-list\u002Fscreen-name\u002F[screenName]\u002Fslug\u002F[slug]",
    "\u002Ftimeline-profile\u002Fscreen-name\u002F[screenName]",
    "\u002Ftimeline-profile\u002Fuser-id\u002F[userId]",
  ],
};
self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();
