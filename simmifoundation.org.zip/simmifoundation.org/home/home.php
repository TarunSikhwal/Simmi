






<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>

  <meta charset="utf-8">
  <title>Simmi Foundation</title>

  <!-- fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@300&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@300&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Lexend&display=swap" rel="stylesheet">
  <link rel="shortcut icon" type="image/x-icon" href="../simmilogo.png">
  <!-- font awesome -->
  <script src="https://kit.fontawesome.com/e395fb5b59.js" crossorigin="anonymous"></script>

  <!-- AOS -->
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

  <!-- css -->
  <link rel="stylesheet" href="home.css">

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

  <!-- fb -->
  <div id="fb-root"></div>
  <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v10.0" nonce="CsRJa0Jg"></script>

  <!--  -->

</head>

<body>

  <!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <style media="screen">

      .rolling-text{
        text-align: middle;
        padding-top: 6px;
        background-color: white;
      }

      nav ul li:hover a{
        color: #f58634!important;
        border-bottom-style: solid;
        border-bottom-width: 3px;
      }

    </style>

  </head>
  <body>

<div class="fixed-top" style="height: 10px!important;">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shift" >
    <a class="navbar-brand px-3" href="#">
      <img src="images/logo.png" alt="" width="35" height="35" class="d-inline-block align-top">
       &ensp;  SIMMI FOUNDATION
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse text-center " id="navbarNav">
      <ul class="navbar-nav ms-auto ">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="../">Home</a>
        </li>
        <li class="nav-item px-3">
          <a class="nav-link" href="../about.php">About</a>
        </li>
        <li class="nav-item px-3">
          <a class="nav-link" href="../donate.php">Donate</a>
        </li>
        <li class="nav-item px-3">
          <a class="nav-link" href="../blogs/">Blog</a>
        </li>
        <li class="nav-item px-3">
          <a class="nav-link" href="../gallery/">Gallery</a>
        </li>
        <li class="nav-item px-3">
          <a class="nav-link" href="../volunteer.php">Volunteer</a>
        </li>
        <li class="nav-item px-3">
          <a class="nav-link" href="../event.php">Events</a>
        </li>
        <li class="nav-item px-3">
          <a class="nav-link" href="../career/">Careers</a>
        </li>
        <li class="nav-item px-3">
          <a class="nav-link" href="../contact.php">Contact</a>
        </li>
      </ul>
    </div>
</nav>

<marquee width="100%" direction="left" height="30px" scrollamount="12" class='rolling-text'>
  Smart India Multi Management Institute! &ensp;  स्मार्ट इंडिया बहुद्देश्यीय प्रबन्धन संस्थान! &ensp; Registration number : 085953/2020  &ensp; Niti Aayog (Govt. Of India ) Unique Id : HR/2020/0258148
</marquee>

</div>

  </body>
</html>


  <!-- Home page slider -->

  <div id="Carouselcontrol" class="carousel slide " data-ride="carousel">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#Carouselcontrol" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#Carouselcontrol" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#Carouselcontrol" data-bs-slide-to="2" aria-label="Slide 3"></button>
      <button type="button" data-bs-target="#Carouselcontrol" data-bs-slide-to="3" aria-label="Slide 4"></button>
    </div>



    <div class="carousel-inner" role="listbox">


      <div class='carousel-item active'>
        <img class='d-block w-100' src='./admin/upload/imga75b483924.jpg' alt=' width='1000px' height='750px'>
      </div><div class='carousel-item '>
        <img class='d-block w-100' src='./admin/upload/img2973827efc.jpg' alt=' width='1000px' height='750px'>
      </div><div class='carousel-item '>
        <img class='d-block w-100' src='./admin/upload/img71e24d0f53.jpg' alt=' width='1000px' height='750px'>
      </div><div class='carousel-item '>
        <img class='d-block w-100' src='./admin/upload/img6e825bdb65.jpeg' alt=' width='1000px' height='750px'>
      </div>      <!-- <div class="carousel-item active">
        <img class="d-block w-100" src="images/home/image1.jpg" alt="" width="100%" height="750px">
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="images/home/image2.jpg" alt="" width="100%" height="750px">
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="images/home/image3.jpg" alt="" width="100%" height="750px">
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="images/home/image4.jpg" alt="" width="100%" height="750px"> -->
      <!-- <div class="carousel-caption d-none d-md-block" >
          <h3 class="caption-text-firstHeading" data-aos="fade-up-right">eget magna fermentum iaculis eu non</h3>
          <h5 class="caption-text-secondHeading" data-aos="fade-up-right">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</h5>
          <div class="carousel-btn">
            <a href="#">
              <button class="donate-btn">Donate now</button>
            </a>
            <a href="#">
              <button class="read-btn">Read More</button>
            </a>
          </div>
        </div> -->
      <!-- </div> -->

    </div>
    <a class="carousel-control-prev" href="#Carouselcontrol" role="button" data-slide="prev">
      <span class="fas fa-angle-left fa-4x" style="color: #f58634;" aria-hidden="true"></span>
      <span class="sr-only"></span>
    </a>
    <a class="carousel-control-next" href="#Carouselcontrol" role="button" data-slide="next">
      <span class="fas fa-angle-right fa-4x" style="color: #f58634;" aria-hidden="true"></span>
      <span class="sr-only"></span>
    </a>
  </div>


  <!-- welcome text -->
  <div class="row" style="background-color:#212529; color:white;">

    <div class="welcome-text col-lg-8" data-aos="fade-up" data-aos-duration="1000">
      <h3 class="body-heading">Welcome to <b class="orange-color">SIMMI</b> </h3>
      <p>Smart India Multi Management Institute is a pan India NGO registered in Haryana, India; carrying out welfare projects on
        education, healthcare, livelihood and women empowerment. We believe that unless members of
        the civil society are involved proactively in the process of development, sustainable change will not
        happen. Based on this, Simmi Foundation sensitizes and engages the civil society, making it an active
        partner in all its welfare initiatives.
      </p>
    </div>
    <div class="map col-lg-4 " data-aos="fade-left" data-aos-duration="1000" style="text-align: center;">
      <img src="images/home/map-dark.png" alt="" height="450" width="350">
    </div>
    <!-- d-none d-lg-block -->
  </div>

  <!-- OBJECTIVES SECTION -->

  <section id="objectives" data-aos="fade-up" data-aos-duration="1000">
    <h3 class="body-heading">Objectives</h3>

    <div class="row body-card">
      <div class="card col-lg-3 col-md-6" data-aos="zoom-out-right" data-aos-duration="1000">
        <img class="card-img-top" src="images/objectives/education.jpg" alt="Card image cap">
        <div class="card-body">
          <h5 class="card-title">Education</h5>
          <p class="card-text">We provide free academic education, scholarship, training and other incentives to the children.</p>
          <div class="card-footer">
            <a href="/about.php">Read more <i class="fas fa-arrow-right fa-1x"></i></a>
          </div>
        </div>
      </div>
      <div class="card col-lg-3 col-md-6" data-aos="zoom-in" data-aos-duration="1000">
        <img class="card-img-top" src="images/objectives/livelihood.jpg" alt="Card image cap">
        <div class="card-body">
          <h5 class="card-title">Livelihood</h5>
          <p class="card-text">We implement various schemes to provide livelihood and uplift the poor in society.</p>
          <div class="card-footer">
            <a href="/about.php">Read more <i class="fas fa-arrow-right fa-1x"></i></a>
          </div>
        </div>
      </div>
      <div class="card col-lg-3 col-md-6" data-aos="zoom-in" data-aos-duration="1000">
        <img class="card-img-top" src="images/objectives/healthcare.jpg" alt="Card image cap">
        <div class="card-body">
          <h5 class="card-title">Healthcare</h5>
          <p class="card-text">We are increasing awareness on Sanitization and providing people with access to better nutrition, clean water and toilets.</p>
          <div class="card-footer">
            <a href="/about.php">Read more <i class="fas fa-arrow-right fa-1x"></i></a>
          </div>
        </div>
      </div>
      <div class="card col-lg-3 col-md-6" data-aos="zoom-out-left" data-aos-duration="1000">
        <img class="card-img-top" src="images/objectives/women empowerment.jpg" alt="Card image cap">
        <div class="card-body">
          <h5 class="card-title">Women and Youth Empowerment</h5>
          <p class="card-text">We focus on providing equal opportunities for women in the work field.</p>
          <div class="card-footer">
            <a href="/about.php">Read more <i class="fas fa-arrow-right fa-1x"></i></a>
          </div>
        </div>
      </div>
    </div>
  </section>


  <!-- How can you help us section -->

  <section id="help-us">

    <h3 class="body-heading" data-aos="zoom-in-up" data-aos-duration="1000">How can you help us</h3>
    <div class="row body-card ">
      <div class="card col-lg-4" data-aos="zoom-in-right" data-aos-duration="1000">
        <div class="card-body">
          <h5 class="card-title">Collaborate</h5>
          <hr>
          <p class="card-text" style="color:white;">Simmi Foundation serves in the collaboration with schools, colleges and other institutions.</p>
          <div class="card-footer">
            <a href="/contact.php">Collaborate with us <i class="fas fa-arrow-right fa-1x"></i></a>
          </div>
        </div>
      </div>
      <div class="card col-lg-4" data-aos="zoom-out" data-aos-duration="1000">
        <div class="card-body">
          <h5 class="card-title">Donate Money</h5>
          <hr>
          <p class="card-text" style="color:white;">Your donation will further our mission of ensuring a happy and healthy life of those in need.</p>
          <div class="card-footer">
            <a href="/donate.php">Donate now <i class="fas fa-arrow-right fa-1x"></i></a>
          </div>
        </div>
      </div>
      <div class="card col-lg-4" data-aos="zoom-in-left" data-aos-duration="1000">
        <div class="card-body">
          <h5 class="card-title">Be a Volunteer</h5>
          <hr>
          <p class="card-text" style="color:white;">Even the all-powerful Pointing has no control about the blind texts.</p>
          <div class="card-footer">
            <a href="/volunteer.php">Read more <i class="fas fa-arrow-right fa-1x"></i></a>
          </div>
        </div>
      </div>
    </div>

  </section>


  <!-- Upcoming events -->
  <section id="event">
    <h3 class="body-heading orange-color">Current and Upcoming events</h3>

    <div class="row body-card">

      


        <div class="card col-md-4" data-aos="zoom-in" data-aos-duration="1000">
          <img class="card-img-top" src="/admin/images/events/bg_3.jpg" alt="Card image cap">
          <div class="card-body">
            <a href="event.php">
              <h5 class="card-title">Marathon Event </h5>
            </a>
            <p class="card-text"><span class="text-muted"><i class="fas fa-map-marked-alt"></i>Delhi </span></p>
            <p class="card-text">
              <span class="text-muted"><i class="fas fa-clock"></i>22:25:00 - 23:25:00 </span>
              <span class="text-muted" style="padding-left: 3%;"><i class="fas fa-calendar-alt"></i>2020-07-09 </span>
            </p>
            <p class="card-text" style="max-height:124px; overflow:hidden" >Lorem Ipsum generator a baeeLorem Ipsum generator a baee Lorem Ipsum generator a baee Lorem Ipsum generator a baee Lorem Ipsum generator a baee </p>
            <div class="card-footer">
              <a href="/event.php">Read more <i class="fas fa-angle-right fa-1x"></i></a>
            </div>
          </div>
        </div>


      


        <div class="card col-md-4" data-aos="zoom-in" data-aos-duration="1000">
          <img class="card-img-top" src="/admin/images/events/Image(17).jpeg" alt="Card image cap">
          <div class="card-body">
            <a href="event.php">
              <h5 class="card-title">event-til </h5>
            </a>
            <p class="card-text"><span class="text-muted"><i class="fas fa-map-marked-alt"></i>india </span></p>
            <p class="card-text">
              <span class="text-muted"><i class="fas fa-clock"></i>02:13:00 - 02:43:00 </span>
              <span class="text-muted" style="padding-left: 3%;"><i class="fas fa-calendar-alt"></i>2021-06-30 </span>
            </p>
            <p class="card-text" style="max-height:124px; overflow:hidden" >event-descevent-descevent-descevent-descevent-descevent-descevent-descevent-descevent-descevent-descevent-descevent-descevent-descevent-descevent-descevent-desc </p>
            <div class="card-footer">
              <a href="/event.php">Read more <i class="fas fa-angle-right fa-1x"></i></a>
            </div>
          </div>
        </div>


      


        <div class="card col-md-4" data-aos="zoom-in" data-aos-duration="1000">
          <img class="card-img-top" src="/admin/images/events/LIVE SESSION DOCTOR.jpg" alt="Card image cap">
          <div class="card-body">
            <a href="event.php">
              <h5 class="card-title">"Know your heart better"  By Dr. Rahul Katariya  </h5>
            </a>
            <p class="card-text"><span class="text-muted"><i class="fas fa-map-marked-alt"></i>India </span></p>
            <p class="card-text">
              <span class="text-muted"><i class="fas fa-clock"></i>16:00:00 - 17:00:00 </span>
              <span class="text-muted" style="padding-left: 3%;"><i class="fas fa-calendar-alt"></i>2021-12-13 </span>
            </p>
            <p class="card-text" style="max-height:124px; overflow:hidden" >"Know your heart better" Catch Dr. Rahul Katariya speak live on the topic cardiac pain on SIMMI foundation's official instagram handle.

Link : https://instagram.com/simmifoundation/

#simmifounda </p>
            <div class="card-footer">
              <a href="/event.php">Read more <i class="fas fa-angle-right fa-1x"></i></a>
            </div>
          </div>
        </div>


      


        <div class="card col-md-4" data-aos="zoom-in" data-aos-duration="1000">
          <img class="card-img-top" src="/admin/images/events/WhatsApp Image 2022-01-16 at 2.55.59 PM.jpeg" alt="Card image cap">
          <div class="card-body">
            <a href="event.php">
              <h5 class="card-title">Coronavirus and the country </h5>
            </a>
            <p class="card-text"><span class="text-muted"><i class="fas fa-map-marked-alt"></i>Instagram  </span></p>
            <p class="card-text">
              <span class="text-muted"><i class="fas fa-clock"></i>15:00:00 - 15:30:00 </span>
              <span class="text-muted" style="padding-left: 3%;"><i class="fas fa-calendar-alt"></i>2022-01-17 </span>
            </p>
            <p class="card-text" style="max-height:124px; overflow:hidden" >The SIMMI FOUNDATION introduces
Dr. Arnab Mandal! Dr. Mandal is an MBBS gold-medallist from RG Kar Medical College and is currently working as a house physician at the department of pediatrics in RG  </p>
            <div class="card-footer">
              <a href="/event.php">Read more <i class="fas fa-angle-right fa-1x"></i></a>
            </div>
          </div>
        </div>


      


        <div class="card col-md-4" data-aos="zoom-in" data-aos-duration="1000">
          <img class="card-img-top" src="/admin/images/events/WhatsApp Image 2022-01-17 at 5.34.33 PM.jpeg" alt="Card image cap">
          <div class="card-body">
            <a href="event.php">
              <h5 class="card-title">Development and empowerment </h5>
            </a>
            <p class="card-text"><span class="text-muted"><i class="fas fa-map-marked-alt"></i>Instagram  </span></p>
            <p class="card-text">
              <span class="text-muted"><i class="fas fa-clock"></i>16:00:00 - 16:30:00 </span>
              <span class="text-muted" style="padding-left: 3%;"><i class="fas fa-calendar-alt"></i>2022-01-18 </span>
            </p>
            <p class="card-text" style="max-height:124px; overflow:hidden" >Ms. Poonam Shroti addresses the unaddressed topic of disability and women empowerment, and the true face of rural development in the country </p>
            <div class="card-footer">
              <a href="/event.php">Read more <i class="fas fa-angle-right fa-1x"></i></a>
            </div>
          </div>
        </div>


      


        <div class="card col-md-4" data-aos="zoom-in" data-aos-duration="1000">
          <img class="card-img-top" src="/admin/images/events/WhatsApp Image 2022-01-18 at 9.31.24 PM.jpeg" alt="Card image cap">
          <div class="card-body">
            <a href="event.php">
              <h5 class="card-title">Wellness and health, a vital concept. </h5>
            </a>
            <p class="card-text"><span class="text-muted"><i class="fas fa-map-marked-alt"></i>Google Meet  </span></p>
            <p class="card-text">
              <span class="text-muted"><i class="fas fa-clock"></i>18:00:00 - 18:30:00 </span>
              <span class="text-muted" style="padding-left: 3%;"><i class="fas fa-calendar-alt"></i>2022-01-19 </span>
            </p>
            <p class="card-text" style="max-height:124px; overflow:hidden" >Ms. Lade talks about the issues of liver disease and how Ayurveda can help in solving the modern problems of today </p>
            <div class="card-footer">
              <a href="/event.php">Read more <i class="fas fa-angle-right fa-1x"></i></a>
            </div>
          </div>
        </div>


      


        <div class="card col-md-4" data-aos="zoom-in" data-aos-duration="1000">
          <img class="card-img-top" src="/admin/images/events/WhatsApp Image 2022-01-20 at 11.05.44 PM.jpeg" alt="Card image cap">
          <div class="card-body">
            <a href="event.php">
              <h5 class="card-title">Mental Health and Motivation </h5>
            </a>
            <p class="card-text"><span class="text-muted"><i class="fas fa-map-marked-alt"></i>Instagram  </span></p>
            <p class="card-text">
              <span class="text-muted"><i class="fas fa-clock"></i>15:00:00 - 15:30:00 </span>
              <span class="text-muted" style="padding-left: 3%;"><i class="fas fa-calendar-alt"></i>2022-01-21 </span>
            </p>
            <p class="card-text" style="max-height:124px; overflow:hidden" >Ms. Papiya talks about mental health and the stigma around it, and how to overcome difficulties in talking about it and treating it. </p>
            <div class="card-footer">
              <a href="/event.php">Read more <i class="fas fa-angle-right fa-1x"></i></a>
            </div>
          </div>
        </div>


      


        <div class="card col-md-4" data-aos="zoom-in" data-aos-duration="1000">
          <img class="card-img-top" src="/admin/images/events/WhatsApp Image 2022-01-20 at 11.05.43 PM.jpeg" alt="Card image cap">
          <div class="card-body">
            <a href="event.php">
              <h5 class="card-title"> Rural Development </h5>
            </a>
            <p class="card-text"><span class="text-muted"><i class="fas fa-map-marked-alt"></i>Instagram  </span></p>
            <p class="card-text">
              <span class="text-muted"><i class="fas fa-clock"></i>16:00:00 - 16:31:00 </span>
              <span class="text-muted" style="padding-left: 3%;"><i class="fas fa-calendar-alt"></i>2022-01-21 </span>
            </p>
            <p class="card-text" style="max-height:124px; overflow:hidden" >Mr. Dushyant talks about rural development, especially infrastructure and roadways </p>
            <div class="card-footer">
              <a href="/event.php">Read more <i class="fas fa-angle-right fa-1x"></i></a>
            </div>
          </div>
        </div>


      


        <div class="card col-md-4" data-aos="zoom-in" data-aos-duration="1000">
          <img class="card-img-top" src="/admin/images/events/WhatsApp Image 2022-01-21 at 8.05.34 PM.jpeg" alt="Card image cap">
          <div class="card-body">
            <a href="event.php">
              <h5 class="card-title">Understanding Archeology </h5>
            </a>
            <p class="card-text"><span class="text-muted"><i class="fas fa-map-marked-alt"></i>Google Meet  </span></p>
            <p class="card-text">
              <span class="text-muted"><i class="fas fa-clock"></i>12:00:00 - 12:30:00 </span>
              <span class="text-muted" style="padding-left: 3%;"><i class="fas fa-calendar-alt"></i>2022-01-22 </span>
            </p>
            <p class="card-text" style="max-height:124px; overflow:hidden" >we dive with Ms. Neha into the field of archeology, as she explains the basics of archeology and the inner workings of libraries </p>
            <div class="card-footer">
              <a href="/event.php">Read more <i class="fas fa-angle-right fa-1x"></i></a>
            </div>
          </div>
        </div>


      


        <div class="card col-md-4" data-aos="zoom-in" data-aos-duration="1000">
          <img class="card-img-top" src="/admin/images/events/WhatsApp Image 2022-01-21 at 7.51.38 PM.jpeg" alt="Card image cap">
          <div class="card-body">
            <a href="event.php">
              <h5 class="card-title"> Understanding Entrepreneurship </h5>
            </a>
            <p class="card-text"><span class="text-muted"><i class="fas fa-map-marked-alt"></i>Instagram  </span></p>
            <p class="card-text">
              <span class="text-muted"><i class="fas fa-clock"></i>18:00:00 - 18:30:00 </span>
              <span class="text-muted" style="padding-left: 3%;"><i class="fas fa-calendar-alt"></i>2022-01-22 </span>
            </p>
            <p class="card-text" style="max-height:124px; overflow:hidden" >Mr. Amman Khurana talks about his journey as an entrepreneur and how he became the "ultimate life coach" </p>
            <div class="card-footer">
              <a href="/event.php">Read more <i class="fas fa-angle-right fa-1x"></i></a>
            </div>
          </div>
        </div>


      

    </div>

  </section>


  <!-- animated number counter -->
  <section id="counter">
    <div class="c-no body-heading container-fluid">
      <div class="row ">
        <div class="col-4 counter-Txt">
          <div class="inner-div" style="background-color: #f8702e;">
            <span class="counter-value" data-count="10">0</span> Countries
          </div>
        </div>
        <div class="col-4 counter-Txt">
          <div class="inner-div" style="background-color:#fa8f3e; padding-left:25%; padding-right:25%;">
            <span class="counter-value" data-count="150">0</span> Projects
          </div>
        </div>
        <div class="col-4 counter-Txt margin-bot-35">
          <div class="inner-div" style="background-color:#f9a93a;">
            <span class="counter-value" data-count="10000">0</span> Volunteers
          </div>
        </div>
      </div>
      <br>
      <div class="row">
        <div class="col-6 counter-Txt">
          <div class="inner-div" style="background-color: #f9a93a; padding-left:22%; padding-right:22%;">
            <span class="counter-value" data-count="20">0</span> States
          </div>
        </div>
        <div class="col-6 counter-Txt">
          <div class="inner-div" style="background-color: #f8702e;">
            <span class="counter-value" data-count="500000">0</span> Benificiries
          </div>
        </div>
      </div>
    </div>
  </section>


  <!-- Fundraisers -->
  <section id="event">
    <h3 class="body-heading orange-color">Fundraisers</h3>
    <div class="welcome-text">
      <p style="padding-bottom: 0px!important; padding-top: 0px!important;">A little change makes all the difference.</p>
    </div>

    <div class="row body-card">
      

        <div class="card col-md-4" data-aos="zoom-out" data-aos-duration="1000">
          <img class="card-img-top" src="/admin/images/fundRaisers/Villagekid.jpg" alt="Card image cap">
          <div class="card-body">
            <a href="#">
              <h5 class="card-title"> Test Fund Raiser Kavach</h5>
            </a>
            <p class="card-text" style="max-height:124px; overflow:hidden">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Nec sagittis aliquam malesuada bibendum arcu vitae elementum curabitur. Sit amet consectetur adipiscing elit duis tristique</p>
            <p class="card-text" style="font-weight: bold;">15000 raised of 30000</p>
            <div class="progress" style="height: 5px;">
              <div class="progress-bar" role="progressbar" style="width: 50%; background-color: #f58634;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <div class="card-footer">
              <a href="#">Read more <i class="fas fa-angle-right fa-1x"></i></a>
            </div>
          </div>
        </div>

      

        <div class="card col-md-4" data-aos="zoom-out" data-aos-duration="1000">
          <img class="card-img-top" src="/admin/images/fundRaisers/fundRaiserKavach.jpeg" alt="Card image cap">
          <div class="card-body">
            <a href="#">
              <h5 class="card-title"> Kavach Initiative</h5>
            </a>
            <p class="card-text" style="max-height:124px; overflow:hidden">Simmi Foundation has taken an initiative Kavach to donate shield masks to the workers who put their lives at risk daily.
Let's make a change during this lockdown Let's make a change during this lockdown to help these workers who do not have the luxury to</p>
            <p class="card-text" style="font-weight: bold;">21000 raised of 150000</p>
            <div class="progress" style="height: 5px;">
              <div class="progress-bar" role="progressbar" style="width: 14%; background-color: #f58634;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <div class="card-footer">
              <a href="#">Read more <i class="fas fa-angle-right fa-1x"></i></a>
            </div>
          </div>
        </div>

      

        <div class="card col-md-4" data-aos="zoom-out" data-aos-duration="1000">
          <img class="card-img-top" src="/admin/images/fundRaisers/WhatsApp Image 2021-11-09 at 10.34.25.jpeg" alt="Card image cap">
          <div class="card-body">
            <a href="#">
              <h5 class="card-title"> Donating Clothes </h5>
            </a>
            <p class="card-text" style="max-height:124px; overflow:hidden">SIMMI FOUNDATION Donated Clothes and blankets to almost 4500 Underprivileged people. As we know how how important is clothes at this winter time, Hence SIMMI Foundation appeal you all to help us in this drive by donating the much you could have.</p>
            <p class="card-text" style="font-weight: bold;">10000 raised of 100000</p>
            <div class="progress" style="height: 5px;">
              <div class="progress-bar" role="progressbar" style="width: 10%; background-color: #f58634;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <div class="card-footer">
              <a href="#">Read more <i class="fas fa-angle-right fa-1x"></i></a>
            </div>
          </div>
        </div>

      

        <div class="card col-md-4" data-aos="zoom-out" data-aos-duration="1000">
          <img class="card-img-top" src="/admin/images/fundRaisers/WhatsApp Image 2021-11-09 at 10.34.25 (40).jpeg" alt="Card image cap">
          <div class="card-body">
            <a href="#">
              <h5 class="card-title"> Education </h5>
            </a>
            <p class="card-text" style="max-height:124px; overflow:hidden">Smart India Multi Management Institute (SIMMI) Foundation working dedicatedly in providing education to underprivileged poor children free of cost. Meanwhile post covid situation our team working on giving Chaupal Classes and almost motivated almost 4500+</p>
            <p class="card-text" style="font-weight: bold;">10000 raised of 500000</p>
            <div class="progress" style="height: 5px;">
              <div class="progress-bar" role="progressbar" style="width: 2%; background-color: #f58634;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <div class="card-footer">
              <a href="#">Read more <i class="fas fa-angle-right fa-1x"></i></a>
            </div>
          </div>
        </div>

      


    </div>
  </section>

  <!-- Prominent speakers -->
  <section id="partners">
    <h3 class="body-heading">Our Prominent Speakers</h3>

    <section class="speakers slider">
      <div class="slide"><a href="https://www.instagram.com/sneha_vithalaniagarwal/"><img src="images/speakers/sneha_agarwal.jpg"></a><br />
        <p>Sneha Vithalaniagarwal</p>
      </div>
      <div class="slide"><a href="https://www.instagram.com/nithi_cj/"><img src="images/speakers/major_nithi.jpg"></a><br />
        <p>Major nithi CJ</p>
      </div>
      <div class="slide"><a href="https://www.instagram.com/sandeepnarwal110/"><img src="images/speakers/sandeep_narwal.jpg"></a><br />
        <p>Sandeepnarwal</p>
      </div>
      <div class="slide"><a href="https://www.instagram.com/mm_runs/"><img src="images/speakers/megha_meelu.jpg"></a><br />
        <p>Megha Meelu</p>
      </div>
      <div class="slide"><a href="https://www.instagram.com/chhillar.mohit/"><img src="images/speakers/mohit_chillar.jpg"></a><br />
        <p>Mohit Chillar</p>
      </div>
      <div class="slide"><a href="https://www.instagram.com/p/B3TqfFOnCuH/?utm_source=ig_web_copy_link"><img src="images/speakers/amit_hooda.jpg"></a><br />
        <p>Amit Hooda</p>
      </div>
      <div class="slide"><a href="https://www.instagram.com/vikashkandola.8/"><img src="images/speakers/vikas_kandola.jpg"></a><br />
        <p>Vikash Kandola</p>
      </div>
      <div class="slide"><a href="https://www.instagram.com/naveen_kumar_goyat/"><img src="images/speakers/naveen_kumar_goyat.jpg"></a><br />
        <p>Naveen Kumar Goyat</p>
      </div>
      <div class="slide"><a href="https://www.instagram.com/kevalkakka/"><img src="images/speakers/kevel_kaka.jpg"></a><br />
        <p>Keval Kakka</p>
      </div>
      <div class="slide"><a href="https://www.instagram.com/k.rohannaidu/"><img src="images/speakers/rohan_naidu.jpg"></a><br />
        <p>K.Rohannaidu</p>
      </div>
      <div class="slide"><a href="https://www.instagram.com/abhimanyuraghav2/"><img src="images/speakers/abhimanyu.jpeg"></a><br />
        <p>Abhimanyu Singh Raghav</p>
      </div>
    </section>
  </section>


  <!-- social media -->
  <section id="sm-page">
    <h3 class="body-heading orange-color">Social Media Handle</h3>
    <div class="row">
      <div class="fb-page col-lg-6 page" data-href="https://www.facebook.com/simmifoundation.org/" data-tabs="timeline" data-width="650" data-height="650" data-small-header="false" data-hide-cover="false" data-show-facepile="true">
        <blockquote cite="https://www.facebook.com/simmifoundation.org/" class="fb-xfbml-parse-ignore">
          <a href="https://www.facebook.com/simmifoundation.org/">SIMMI Foundation</a>
        </blockquote>
      </div>
      <div class="col-lg-6 page" style="margin-left:-22px;">
        <a class="twitter-timeline" data-width="450" data-height="650" data-theme="light" href="https://twitter.com/simmifoundation?ref_src=twsrc%5Etfw">Tweets by simmifoundation</a>
        <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
      </div>
    </div>
  </section>




  <!-- our partners -->
  <section id="partners">
    <h3 class="body-heading">Our Partners</h3>

    <section class="customer-logos slider">
      <div class="slide"><a href="https://www.mirandahouse.ac.in/"><img src="images/our_partners/mirandahouse_logo.png"></a><br>
        <p>Miranda House, DU</p>
      </div>
      <div class="slide"><a href="https://www.upes.ac.in/"><img src="images/our_partners/upes_logo.png"></a><br />
        <p>UPES, Dehradun</p>
      </div>
      <div class="slide"><a href="http://www.svc.ac.in/"><img src="images/our_partners/sri_venkateswara_logo.jpeg"></a><br />
        <p>Sri Venkateswara College, DU</p>
      </div>
      <div class="slide"><a href="https://www.tiss.edu/view/15/hyderabad-campus/"><img src="images/our_partners/tiss_logo.png"></a><br />
        <p>TISS, Hyderabad</p>
      </div>
      <div class="slide"><a href="https://www.iitbhilai.ac.in/"><img src="images/our_partners/iitbhilai_logo.png"></a><br />
        <p>IIT Bhilai</p>
      </div>
      <div class="slide"><a href="http://gargi.du.ac.in/"><img src="images/our_partners/gargi_logo.jpeg"></a><br />
        <p>Gargi College, DU</p>
      </div>
      <div class="slide"><a href="http://dsc.du.ac.in/"><img src="images/our_partners/dyalsingh_logo.jpeg"></a><br />
        <p>Dyal Singh College, DU</p>
      </div>
      <div class="slide"><a href="https://sgtbkhalsadu.ac.in/"><img src="images/our_partners/sgtb_logo.png"></a><br />
        <p>Shri Guru Teg Bahadur Khalsa College, DU</p>
      </div>
      <div class="slide"><a href="https://mccblr.edu.in/"><img src="images/our_partners/mca_logo.png"></a><br />
        <p>Mount Carmel College, Bangalore</p>
      </div>
      <div class="slide"><a href="https://simsree.org/Simsree/"><img src="images/our_partners/simsree_logo.png"></a><br />
        <p>SIMSREE, Mumbai</p>
      </div>
      <div class="slide"><a href="https://www.amity.edu/raipur/?utm_source=google&utm_medium=local-listing&utm_campaign=organic"><img src="images/our_partners/amity_logo.png"></a><br />
        <p>Amity University</p>
      </div>
      <div class="slide"><a href="https://igu.ac.in/2021/"><img src="images/our_partners/igu_logo.png"></a><br />
        <p> IGU Meerpur University, Haryana</p>
      </div>
      <div class="slide"><a href="https://www.lpu.in/"><img src="images/our_partners/lpu_logo.png"></a><br />
        <p>LPU, Punjab</p>
      </div>
    </section>


    <!-- <div class="row">
    <div class="ind-partner col-lg-2 col-md-2 col-sm-6" data-aos="fade-up" data-aos-duration="1000">
      <img src="images/logo.png" height="100" width="100" alt="">
      <p class="orange-color">Partner 1</p>
    </div>
    <div class="ind-partner col-lg-2 col-md-2 col-sm-6" data-aos="fade-up" data-aos-duration="1000">
      <img src="images/logo.png" height="100" width="100" alt="">
      <p class="orange-color">Partner 2</p>
    </div>
    <div class="ind-partner col-lg-2 col-md-2 col-sm-6" data-aos="fade-up" data-aos-duration="1000">
      <img src="images/logo.png" height="100" width="100" alt="">
      <p class="orange-color">Partner 3</p>
    </div>
    <div class="ind-partner col-lg-2 col-md-2 col-sm-6" data-aos="fade-up" data-aos-duration="1000">
      <img src="images/logo.png" height="100" width="100" alt="">
      <p class="orange-color">Partner 4</p>
    </div>
    <div class="ind-partner col-lg-2 col-md-2 col-sm-6" data-aos="fade-up" data-aos-duration="1000">
      <img src="images/logo.png" height="100" width="100" alt="">
      <p class="orange-color">Partner 5</p>
    </div>
    <div class="ind-partner col-lg-2 col-md-2 col-sm-6" data-aos="fade-up" data-aos-duration="1000">
      <img src="images/logo.png" height="100" width="100" alt="">
      <p class="orange-color">Partner 6</p>
    </div>
  </div> -->

  </section>




  <head>

  <!-- fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@300&display=swap" rel="stylesheet">

  <!-- font awesome -->
  <script src="https://kit.fontawesome.com/e395fb5b59.js" crossorigin="anonymous"></script>

  <!-- AOS -->
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">


  <style media="screen">


      .ftco-section {
        padding: 7em 0;
        position: relative; }
        @media (max-width: 767.98px) {
          .ftco-section {
            padding: 6em 0; } }

      .ftco-bg-dark {
        background: #3c312e;
      }

      .ftco-footer {
      font-size: 16px;
      padding: 7em 0;
      background: #252525;
      }

      .ftco-footer .ftco-footer-logo {
        text-transform: uppercase;
        letter-spacing: .1em;
      }

      .ftco-footer .ftco-footer-widget h2 {
        font-weight: normal;
        color: #fff;
        margin-bottom: 40px;
        font-size: 18px;
        font-weight: 400;
        position: relative;
        text-transform: uppercase;
        letter-spacing: 1px;
      }

      .ftco-footer .ftco-footer-widget h2:after {
          position: absolute;
          bottom: -15px;
          left: 0;
          content: '';
          width: 70px;
          height: 1px;
          background: #fff;
        }

      .ftco-footer .ftco-footer-widget ul li a span {
        color: #fff;
      }

      .ftco-footer .ftco-footer-widget .btn-primary {
        background: #fff !important;
        border: 2px solid #fff !important;
      }

      .ftco-footer .ftco-footer-widget .btn-primary:hover {
          background: #fff;
          border: 2px solid #fff !important;
        }

      .ftco-footer p {
        color: rgba(255, 255, 255, 0.7);
      }

      .ftco-footer a {
        color: rgba(255, 255, 255, 0.7);
      }

      .ftco-footer a:hover {
          color: #f58634;
      }

      .ftco-footer .ftco-heading-2 {
        font-size: 17px;
        font-weight: 400;
        color: #000;
      }


      .ftco-footer-social li {
      list-style: none;
      margin: 0 10px 0 0;
      display: inline-block;
     }

    .ftco-footer-social li a {
        height: 50px;
        width: 50px;
        display: block;
        float: left;
        background: rgba(255, 255, 255, 0.05);
        border-radius: 50%;
        position: relative;
    }

    .ftco-footer-social li a i {
        position: absolute;
        font-size: 26px;
        top: 50%;
        left: 50%;
        -webkit-transform: translate(-50%, -50%);
        -ms-transform: translate(-50%, -50%);
        transform: translate(-50%, -50%);
    }

      .ftco-footer-social li a:hover {
          color: #f58634;
      }

      .mb-4,.my-4 {
          margin-bottom: 1.5rem !important;
        }

      .list-unstyled {
        padding-left: 0;
        list-style: none;
      }

      .footer-text{
        font-family: 'Source Sans Pro', sans-serif;
        font-size: 1.1rem;
      }

      .d-block {
          display: block!important;
          text-decoration: none;
      }

      .cf{
        padding-bottom: 8px;
      }

      .block-23 ul {
        padding: 0;
      }

      .block-23 ul li, .block-23 ul li > a {
        display: table;
        line-height: 1.5;
        margin-bottom: 15px;
        text-decoration: none;
      }

    .ftco-footer .ftco-footer-widget ul li a span:hover{
        color: #f58634!important;
      }

      .ftco-footer .ftco-footer-widget ul li a i:hover{
        color: #f58634;
      }

      .block-23 ul li span {
        color: rgba(255, 255, 255, 0.7)!important;
      }

      .block-23 ul li .icon, .block-23 ul li .text {
        display: table-cell;
        vertical-align: top;
      }

      .block-23 ul li .icon {
        width: 40px;
        font-size: 18px;
        padding-top: 2px;
        color: white;
      }

  </style>

</head>
<body>

<footer class="ftco-footer ftco-section img" style="padding-bottom:0.5rem">
  <div class="overlay"></div>
  <div class="container">
  <div class="row mb-2">
      <div class="col-md-4">
      <div class="ftco-footer-widget mb-4">
          <h2 class="ftco-heading-2">About Us</h2>
          <p class='footer-text'>We envisions to develop a society based on legitimate rights, equity, justice, honesty, social sensitivity and a culture of service in which all are self-reliant. </p>
          <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
          <li class="ftco-animate" data-aos="fade-up"><a href="https://twitter.com/simmifoundation/ " target="_blank"><i class="fab fa-twitter"></i></a></li>
          <li class="ftco-animate" data-aos="fade-up"><a href="https://fb.me/simmifoundation.org" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
          <li class="ftco-animate" data-aos="fade-up"><a href="https://www.instagram.com/simmifoundation/" target="_blank"><i class="fab fa-instagram"></i></a></li>
          </ul>
      </div>
      </div>
      <div class="col-md-5">
      <div class="ftco-footer-widget mb-4">
          <h2 class="ftco-heading-2">Initiatives</h2>
              <div class="row">
                  <div class="col-md-5">
                      <ul class="list-unstyled">
                      <li><a href="../Khel-Sanghthan.php" class="py-2 d-block"> Khel Sangathan</a></li>
                      <li><a href="../Sukoon-Parikram.php" class="py-2 d-block">Sukoon Parikram </a></li>
                      <li><a href="../Simmi-Olympiads.php" class="py-2 d-block">Simmi Olympiads </a></li>
                      <li><a href="../Kalaakaar-manch.php" class="py-2 d-block">Kalaakaar Manch</a></li>
                      </ul>
                  </div>
          <div class="col-md-7">
          <ul class="list-unstyled">
          <li><a href="../Sanskritik-Setu.php" class="py-2 d-block">Sanskritik Setu</a></li>
          <li><a href="../Sambhav-Madad.php" class="py-2 d-block">Sambhav Madad</a></li>
          </ul>
          </div>
     </div>
          </div>
      </div>
      <div class="col-md-3">
      <div class="ftco-footer-widget mb-4">
          <h2 class="ftco-heading-2">Have Questions?</h2>
          <div class="block-23">
              <ul>
              <li><a><i class="icon fas fa-map-marker-alt"></i> <span class="text">479, Baspadamka, Tehsil Pataudi, Gurugram, Haryana - 122503, India</span></li></a>
              <li><a href="#" ><i class="icon fas fa-phone-alt"></i> <span class="text">(+91) 70152 - 95025</span></a></li>
              <li><a href="mailto: support@simmifoundation.org"><i class="icon fas fa-envelope"></i> <span class="text">support@simmifoundation.org</span></a></li>
              </ul>
          </div>
      </div>
      </div>
  </div>
  <div class="row">
      <div class="col-md-12 text-center">
        <img src="images/logo.png" height="50px">
        <img src="images/NITI-Aayog-logo.png" height="50px">
      <p>Our Registration number : 085953/2020<br>
      Niti Aayog (Govt. Of India ) Unique Id : HR/2020/0258148<br>
      <hr><p >Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Simmi Foundation
      <i class="fas fa-heart"></i></p></p>
      </div>
  </div>
  </div>
</footer>

<!-- AOS SCRIPT -->
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
   AOS.init();
</script>

</body>

  <!-- AOS SCRIPT -->
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <!-- Partners Slider -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
  <script src="home.js" charset="utf-8"></script>

</body>

</html>