if (self.CavalryLogger) {
  CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d(
  "ChannelConstants",
  [],
  function (a, b, c, d, e, f) {
    var g = "channel/";
    a = {
      CHANNEL_MANUAL_RECONNECT_DEFER_MSEC: 2e3,
      MUTE_WARNING_TIME_MSEC: 25e3,
      WARNING_COUNTDOWN_THRESHOLD_MSEC: 15e3,
      ON_SHUTDOWN: g + "shutdown",
      ON_INVALID_HISTORY: g + "invalid_history",
      ON_CONFIG: g + "config",
      ON_ENTER_STATE: g + "enter_state",
      ON_EXIT_STATE: g + "exit_state",
      ATTEMPT_RECONNECT: g + "attempt_reconnect",
      RTI_SESSION: g + "new_rti_address",
      CONSOLE_LOG: g + "message:console_log",
      GET_RTI_SESSION_REQUEST: g + "rti_session_request",
      SKYWALKER: g + "skywalker",
      CHANNEL_ESTABLISHED: g + "established",
      OK: "ok",
      ERROR: "error",
      ERROR_MAX: "error_max",
      ERROR_MISSING: "error_missing",
      ERROR_MSG_TYPE: "error_msg_type",
      ERROR_SHUTDOWN: "error_shutdown",
      ERROR_STALE: "error_stale",
      SYS_OWNER: "sys_owner",
      SYS_NONOWNER: "sys_nonowner",
      SYS_ONLINE: "sys_online",
      SYS_OFFLINE: "sys_offline",
      SYS_TIMETRAVEL: "sys_timetravel",
      HINT_AUTH: "shutdown auth",
      HINT_CONN: "shutdown conn",
      HINT_DISABLED: "shutdown disabled",
      HINT_INVALID_STATE: "shutdown invalid state",
      HINT_MAINT: "shutdown maint",
      HINT_UNSUPPORTED: "shutdown unsupported",
      reason_Unknown: 0,
      reason_AsyncError: 1,
      reason_TooLong: 2,
      reason_Refresh: 3,
      reason_RefreshDelay: 4,
      reason_UIRestart: 5,
      reason_NeedSeq: 6,
      reason_PrevFailed: 7,
      reason_IFrameLoadGiveUp: 8,
      reason_IFrameLoadRetry: 9,
      reason_IFrameLoadRetryWorked: 10,
      reason_PageTransitionRetry: 11,
      reason_IFrameLoadMaxSubdomain: 12,
      reason_NoChannelInfo: 13,
      reason_NoChannelHost: 14,
      CAPABILITY_VOIP_INTEROP: 8,
      CAPABILITY_ACTIVE_ON_DESKTOP_APP: 16384,
      CAPABILITY_PLAYING_INSTANT_GAME: 2097152,
      FANTAIL_SERVICE: "WebchatClient",
      SUBSCRIBE: "subscribe",
      UNSUBSCRIBE: "unsubscribe",
      FAKE_DFF: "fake_dff",
      THROTTLED: g + "throttled",
      JUMPSTART: g + "jumpstart",
      ENTITY_PRESENCE_ACTIVE_PING: "entity_presence/active_ping",
      ENTITY_PRESENCE_SKIPPED_PING: "entity_presence/skipped_ping",
      SUBSCRIPTION_STATE: {
        SUBSCRIBE: "s",
        MUTATE_CONTEXT: "m",
        UNSUBSCRIBE: "u",
      },
      DEFAULT_MAX_SUBSCRIPTIONS: 300,
      DEFAULT_EVICTION_BATCH_SIZE: 20,
      DEFAULT_MAX_SUBSCRIPTION_FLUSH_BATCH_SIZE: 300,
      DEFAULT_MAX_CONSECUTIVE_FLUSH_FAILURES: 3,
      getArbiterType: function (a) {
        return g + "message:" + a;
      },
      getRTISkywalkerArbiterType: function (a, b) {
        return g + "skywalker:" + a + ":" + b;
      },
    };
    e.exports = a;
  },
  null,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "AvailableListConstants",
  [],
  function (a, b, c, d, e, f) {
    a = Object.freeze({
      ON_AVAILABILITY_CHANGED: "buddylist/availability-changed",
      ON_UPDATE_ERROR: "buddylist/update-error",
      ON_UPDATED: "buddylist/updated",
      ON_CHAT_NOTIFICATION_CHANGED: "chat-notification-changed",
      OFFLINE: 0,
      IDLE: 1,
      ACTIVE: 2,
      MOBILE: 3,
      WEB_STATUS: "webStatus",
      FB_APP_STATUS: "fbAppStatus",
      MESSENGER_STATUS: "messengerStatus",
      OTHER_STATUS: "otherStatus",
      STATUS_ACTIVE: "active",
      STATUS_IDLE: "idle",
      STATUS_OFFLINE: "offline",
    });
    f["default"] = a;
  },
  66,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "PresenceConfig",
  ["PresenceConfigInitialData"],
  function (a, b, c, d, e, f, g) {
    var h = babelHelpers["extends"]({}, c("PresenceConfigInitialData"));
    function a(a, b) {
      return a in h ? h[a] : b;
    }
    g.get = a;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "Base64",
  [],
  function (a, b, c, d, e, f) {
    var g = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    function h(a) {
      a = (a.charCodeAt(0) << 16) | (a.charCodeAt(1) << 8) | a.charCodeAt(2);
      return String.fromCharCode(
        g.charCodeAt(a >>> 18),
        g.charCodeAt((a >>> 12) & 63),
        g.charCodeAt((a >>> 6) & 63),
        g.charCodeAt(a & 63)
      );
    }
    var i =
      ">___?456789:;<=_______\0\x01\x02\x03\x04\x05\x06\x07\b\t\n\v\f\r\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19______\x1a\x1b\x1c\x1d\x1e\x1f !\"#$%&'()*+,-./0123";
    function j(a) {
      a =
        (i.charCodeAt(a.charCodeAt(0) - 43) << 18) |
        (i.charCodeAt(a.charCodeAt(1) - 43) << 12) |
        (i.charCodeAt(a.charCodeAt(2) - 43) << 6) |
        i.charCodeAt(a.charCodeAt(3) - 43);
      return String.fromCharCode(a >>> 16, (a >>> 8) & 255, a & 255);
    }
    var k = {
      encode: function (a) {
        a = unescape(encodeURI(a));
        var b = (a.length + 2) % 3;
        a = (a + "\0\0".slice(b)).replace(/[\s\S]{3}/g, h);
        return a.slice(0, a.length + b - 2) + "==".slice(b);
      },
      decode: function (a) {
        a = a.replace(/[^A-Za-z0-9+\/]/g, "");
        var b = (a.length + 3) & 3;
        a = (a + "AAA".slice(b)).replace(/..../g, j);
        a = a.slice(0, a.length + b - 3);
        try {
          return decodeURIComponent(escape(a));
        } catch (a) {
          throw new Error("Not valid UTF-8");
        }
      },
      encodeObject: function (a) {
        return k.encode(JSON.stringify(a));
      },
      decodeObject: function (a) {
        return JSON.parse(k.decode(a));
      },
      encodeNums: function (a) {
        return String.fromCharCode.apply(
          String,
          a.map(function (a) {
            return g.charCodeAt(
              (a | -(a > 63 ? 1 : 0)) & -(a > 0 ? 1 : 0) & 63
            );
          })
        );
      },
    };
    a = k;
    f["default"] = a;
  },
  66,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "CometLruCache",
  ["recoverableViolation"],
  function (a, b, c, d, e, f, g) {
    "use strict";
    var h = (function () {
      function a(a) {
        (this.$1 = a),
          a <= 0 &&
            c("recoverableViolation")(
              "CometLruCache: Unable to create instance of cache with zero or negative capacity.",
              "CometLruCache"
            ),
          (this.$2 = new Map());
      }
      var b = a.prototype;
      b.set = function (a, b) {
        this.$2["delete"](a);
        this.$2.set(a, b);
        if (this.$2.size > this.$1) {
          a = this.$2.keys().next();
          a.done || this.$2["delete"](a.value);
        }
      };
      b.get = function (a) {
        var b = this.$2.get(a);
        b != null && (this.$2["delete"](a), this.$2.set(a, b));
        return b;
      };
      b.has = function (a) {
        return this.$2.has(a);
      };
      b["delete"] = function (a) {
        this.$2["delete"](a);
      };
      b.size = function () {
        return this.$2.size;
      };
      b.capacity = function () {
        return this.$1 - this.$2.size;
      };
      b.clear = function () {
        this.$2.clear();
      };
      return a;
    })();
    function a(a) {
      return new h(a);
    }
    g.create = a;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "ConstUriUtils",
  [
    "CometLruCache",
    "FBLogger",
    "PHPQuerySerializer",
    "PHPQuerySerializerNoEncoding",
    "URIRFC3986",
    "URISchemes",
    "UriNeedRawQuerySVConfig",
    "recoverableViolation",
  ],
  function (a, b, c, d, e, f, g) {
    "use strict";
    var h = d("CometLruCache").create(5e3),
      i = new RegExp("(^|\\.)facebook\\.com$", "i"),
      j = new RegExp("^(?:[^/]*:|[\\x00-\\x1f]*/[\\x00-\\x1f]*/)"),
      k = new RegExp(
        "[\\x00-\\x2c\\x2f\\x3b-\\x40\\x5c\\x5e\\x60\\x7b-\\x7f\\uFDD0-\\uFDEF\\uFFF0-\\uFFFF\\u2047\\u2048\\uFE56\\uFE5F\\uFF03\\uFF0F\\uFF1F]"
      ),
      l = c("UriNeedRawQuerySVConfig").uris.map(function (a) {
        return { domain: a, valid: r(a) };
      }),
      m = [];
    function n(a, b) {
      var d = {};
      if (a != null)
        for (
          var a = a.entries(),
            e = Array.isArray(a),
            f = 0,
            a = e
              ? a
              : a[
                  typeof Symbol === "function" ? Symbol.iterator : "@@iterator"
                ]();
          ;

        ) {
          var g;
          if (e) {
            if (f >= a.length) break;
            g = a[f++];
          } else {
            f = a.next();
            if (f.done) break;
            g = f.value;
          }
          g = g;
          d[g[0]] = g[1];
        }
      else
        c("FBLogger")("ConstUriUtils").warn(
          "Passed a null query map in, this means poor client side flow coverage or client/server boundary type issue."
        );
      return b.serialize(d);
    }
    function o(a, b, d) {
      var e = c("PHPQuerySerializer");
      if (["http", "https"].includes(b) && p(a)) {
        if (a.includes("doubleclick.net") && d != null && !d.startsWith("http"))
          return e;
        e = c("PHPQuerySerializerNoEncoding");
      }
      return e;
    }
    function p(a) {
      return (
        a != null &&
        l.some(function (b) {
          return b.valid && q(a, b.domain);
        })
      );
    }
    function q(a, b) {
      if (b === "" || a === "") return !1;
      if (a.endsWith(b)) {
        b = a.length - b.length - 1;
        if (b === -1 || a[b] === ".") return !0;
      }
      return !1;
    }
    function r(a) {
      return !k.test(a);
    }
    function s(a, b) {
      var c =
        b.protocol != null && b.protocol !== "" ? b.protocol : a.getProtocol();
      c = b.domain != null ? o(b.domain, c) : a.getSerializer();
      c = {
        domain: a.getDomain(),
        fragment: a.getFragment(),
        fragmentSeparator: a.hasFragmentSeparator(),
        isGeneric: a.isGeneric(),
        originalRawQuery: a.getOriginalRawQuery(),
        path: a.getPath(),
        port: a.getPort(),
        protocol: a.getProtocol(),
        queryParams: a.getQueryParams(),
        serializer: c,
        subdomain: a.getSubdomain(),
      };
      a = babelHelpers["extends"]({}, c, b);
      c = b.queryParams != null && b.queryParams.size !== 0;
      return x.getUribyObject(a, c);
    }
    function t(a, b, c, d) {
      c === void 0 && (c = !1);
      var e =
          a.protocol !== "" ? a.protocol + ":" + (a.isGeneric ? "" : "//") : "",
        f = a.domain !== "" ? a.domain : "",
        g = a.port !== "" ? ":" + a.port : "",
        h =
          a.path !== ""
            ? a.path
            : (e !== "" && e !== "mailto:") || f !== "" || g !== ""
            ? "/"
            : "";
      c = u(
        f,
        a.originalRawQuery,
        a.queryParams,
        b,
        c,
        (b = d) != null ? b : a.serializer
      );
      d = c.length > 0 ? "?" : "";
      b = a.fragment !== "" ? "#" + a.fragment : "";
      a = a.fragment === "" && a.fragmentSeparator ? "#" : "";
      return "" + e + f + g + h + d + c + a + b;
    }
    function u(a, b, c, d, e, f) {
      e === void 0 && (e = !1);
      if (!d && (e || p(a))) {
        return (d = b) != null ? d : "";
      }
      return n(c, f);
    }
    function v(a) {
      var b = a.trim();
      b = d("URIRFC3986").parse(b) || {
        fragment: null,
        host: null,
        isGenericURI: !1,
        query: null,
        scheme: null,
        userinfo: null,
      };
      var c = b.host || "",
        e = c.split(".");
      e = e.length >= 3 ? e[0] : "";
      var f = o(c, b.scheme || "", b.query),
        g = f.deserialize(b.query || "") || {};
      g = new Map(Object.entries(g));
      g = w(
        {
          domain: c,
          fragment: b.fragment || "",
          fragmentSeparator: b.fragment === "",
          isGeneric: b.isGenericURI,
          originalRawQuery: b.query,
          path: b.path || "",
          port: b.port != null ? String(b.port) : "",
          protocol: (b.scheme || "").toLowerCase(),
          queryParams: g,
          serializer: f,
          subdomain: e,
          userInfo: (c = b == null ? void 0 : b.userinfo) != null ? c : "",
        },
        a
      );
      return g;
    }
    function w(a, b) {
      var c = {
          components: babelHelpers["extends"]({}, a),
          error: "",
          valid: !0,
        },
        e = c.components;
      if (!d("URISchemes").isAllowed(a.protocol)) {
        c.valid = !1;
        c.error =
          'The URI protocol "' + String(a.protocol) + '" is not allowed.';
        return c;
      }
      if (!r(a.domain || "")) {
        c.valid = !1;
        c.error = "This is an unsafe domain " + String(a.domain);
        return c;
      }
      e.port = (a.port != null && String(a.port)) || "";
      if (Boolean(a.userInfo)) {
        c.valid = !1;
        c.error =
          "Invalid URI: (userinfo is not allowed in a URI " +
          String(a.userInfo) +
          ")";
        return c;
      }
      a = b != null && b !== "" ? b : t(e, !1);
      if (e.domain === "" && e.path.indexOf("\\") !== -1) {
        c.valid = !1;
        c.error =
          "Invalid URI: (no domain but multiple back-slashes " + a + ")";
        return c;
      }
      if (!e.protocol && j.test(a)) {
        c.valid = !1;
        c.error = "Invalid URI: (unsafe protocol-relative URI " + a + ")";
        return c;
      }
      if (e.domain !== "" && e.path !== "" && !e.path.startsWith("/")) {
        c.valid = !1;
        c.error =
          "Invalid URI: (domain and pathwhere path lacks leading slash " +
          a +
          ")";
        return c;
      }
      return c;
    }
    var x = (function () {
      function a(a) {
        (this.queryParams = new Map()),
          (this.domain = a.domain),
          (this.fragment = a.fragment),
          (this.fragmentSeparator = Boolean(a.fragmentSeparator)),
          (this.isGenericProtocol = Boolean(a.isGeneric)),
          (this.path = a.path),
          (this.originalRawQuery = a.originalRawQuery),
          (this.port = a.port),
          (this.protocol = a.protocol),
          (this.queryParams = a.queryParams),
          (this.serializer = a.serializer),
          (this.subdomain = a.subdomain);
      }
      var b = a.prototype;
      b.addQueryParam = function (a, b) {
        if (Boolean(a)) {
          var c = this.getQueryParams();
          c.set(a, b);
          return s(this, { queryParams: c });
        }
        return this;
      };
      b.addQueryParams = function (a) {
        if (a.size > 0) {
          var b = this.getQueryParams();
          a.forEach(function (a, c) {
            b.set(c, a);
          });
          return s(this, { queryParams: b });
        }
        return this;
      };
      b.addQueryParamString = function (a) {
        if (Boolean(a)) {
          a = a.startsWith("?") ? a.slice(1) : a;
          var b = this.getQueryParams();
          a.split("&").map(function (a) {
            a = a.split("=");
            var c = a[0];
            a = a[1];
            b.set(c, a);
          });
          return s(this, { queryParams: b });
        }
        return this;
      };
      b.addTrailingSlash = function () {
        var a = this.getPath();
        return a.length > 0 && a[a.length - 1] !== "/"
          ? this.setPath(a + "/")
          : this;
      };
      b.getDomain = function () {
        return this.domain;
      };
      b.getFragment = function () {
        return this.fragment;
      };
      b.getOrigin = function () {
        var a = this.getPort();
        return (
          this.getProtocol() + "://" + this.getDomain() + (a ? ":" + a : "")
        );
      };
      b.getOriginalRawQuery = function () {
        return this.originalRawQuery;
      };
      b.getPath = function () {
        return this.path;
      };
      b.getPort = function () {
        return this.port;
      };
      b.getProtocol = function () {
        return this.protocol.toLowerCase();
      };
      b.getQualifiedUri = function () {
        if (!this.getDomain()) {
          var b = String(window.location.href);
          b = b.slice(0, b.indexOf("/", b.indexOf(":") + 3));
          return a.getUri(b + this.toString());
        }
        return this;
      };
      b.getQueryParam = function (a) {
        a = this.queryParams.get(a);
        if (typeof a === "string") return a;
        else {
          a = JSON.stringify(a);
          return a == null ? a : JSON.parse(a);
        }
      };
      b.getQueryData = function () {
        return Object.fromEntries(this.getQueryParams());
      };
      b.getQueryParams = function () {
        return new Map(
          JSON.parse(JSON.stringify(Array.from(this.queryParams)))
        );
      };
      b.getQueryString = function (a) {
        a === void 0 && (a = !1);
        return u(
          this.domain,
          this.originalRawQuery,
          this.queryParams,
          !1,
          a,
          this.serializer
        );
      };
      b.getRegisteredDomain = function () {
        if (!this.getDomain()) return "";
        if (!this.isFacebookUri()) return null;
        var a = this.getDomain().split("."),
          b = a.indexOf("facebook");
        b === -1 && (b = a.indexOf("workplace"));
        return a.slice(b).join(".");
      };
      b.getSerializer = function () {
        return this.serializer;
      };
      b.getSubdomain = function () {
        return this.subdomain;
      };
      b.getUnqualifiedUri = function () {
        if (this.getDomain()) {
          var b = this.toString();
          return a.getUri(b.slice(b.indexOf("/", b.indexOf(":") + 3)));
        }
        return this;
      };
      a.getUri = function (b) {
        b = b.trim();
        var d = h.get(b);
        if (d == null) {
          var e = v(b);
          if (e.valid) (d = new a(e.components)), h.set(b, d);
          else {
            c("FBLogger")("ConstUriUtils").blameToPreviousFrame().warn(e.error);
            return null;
          }
        }
        return d;
      };
      a.getUribyObject = function (b, d) {
        var e = t(b, d),
          f = h.get(e);
        if (f == null) {
          d && (b.originalRawQuery = n(b.queryParams, b.serializer));
          d = w(b);
          if (d.valid) (f = new a(d.components)), h.set(e, f);
          else {
            c("recoverableViolation")(d.error, "ConstUri");
            return null;
          }
        }
        return f;
      };
      b.hasFragmentSeparator = function () {
        return this.fragmentSeparator;
      };
      b.isEmpty = function () {
        return !(
          this.getPath() ||
          this.getProtocol() ||
          this.getDomain() ||
          this.getPort() ||
          this.queryParams.size > 0 ||
          this.getFragment()
        );
      };
      b.isFacebookUri = function () {
        var a = this.toString();
        if (a === "") return !1;
        return !this.getDomain() && !this.getProtocol()
          ? !0
          : ["https", "http"].indexOf(this.getProtocol()) !== -1 &&
              i.test(this.getDomain());
      };
      b.isGeneric = function () {
        return this.isGenericProtocol;
      };
      b.isSameOrigin = function (a) {
        if (this.getProtocol() && this.getProtocol() !== a.getProtocol())
          return !1;
        if (this.getDomain() && this.getDomain() !== a.getDomain()) return !1;
        if (this.getPort() && this.getPort() !== a.getPort()) return !1;
        return this.toString() === "" || a.toString() === "" ? !1 : !0;
      };
      b.isSubdomainOfDomain = function (b) {
        var c = a.getUri(b);
        return c != null && q(this.domain, b);
      };
      b.isSecure = function () {
        return this.getProtocol() === "https";
      };
      b.removeQueryParams = function (a) {
        if (Array.isArray(a) && a.length > 0) {
          var b = this.getQueryParams();
          a.map(function (a) {
            return b["delete"](a);
          });
          return s(this, { queryParams: b });
        }
        return this;
      };
      b.removeQueryParam = function (a) {
        if (Boolean(a)) {
          var b = this.getQueryParams();
          b["delete"](a);
          return s(this, { queryParams: b });
        }
        return this;
      };
      b.replaceQueryParam = function (a, b) {
        if (Boolean(a)) {
          var c = this.getQueryParams();
          c.set(a, b);
          return s(this, { queryParams: c });
        }
        return this;
      };
      b.replaceQueryParams = function (a) {
        return s(this, { queryParams: a });
      };
      b.replaceQueryParamString = function (a) {
        if (a != null) {
          a = a.startsWith("?") ? a.slice(1) : a;
          var b = this.getQueryParams();
          a.split("&").map(function (a) {
            a = a.split("=");
            var c = a[0];
            a = a[1];
            b.set(c, a);
          });
          return s(this, { queryParams: b });
        }
        return this;
      };
      b.setDomain = function (a) {
        if (Boolean(a)) {
          var b = a.split(".");
          b = b.length >= 3 ? b[0] : "";
          return s(this, { domain: a, subdomain: b });
        }
        return this;
      };
      b.setFragment = function (a) {
        return a === "#"
          ? s(this, { fragment: "", fragmentSeparator: !0 })
          : s(this, { fragment: a, fragmentSeparator: a !== "" });
      };
      b.setPath = function (a) {
        return a != null ? s(this, { path: a }) : this;
      };
      b.setPort = function (a) {
        return Boolean(a) ? s(this, { port: a }) : this;
      };
      b.setProtocol = function (a) {
        return Boolean(a) ? s(this, { protocol: a }) : this;
      };
      b.setSecure = function (a) {
        return this.setProtocol(a ? "https" : "http");
      };
      b.setSubDomain = function (a) {
        if (Boolean(a)) {
          var b = this.domain.split(".");
          b.length >= 3 ? (b[0] = a) : b.unshift(a);
          return s(this, { domain: b.join("."), subdomain: a });
        }
        return this;
      };
      b.stripTrailingSlash = function () {
        return this.setPath(this.getPath().replace(/\/$/, ""));
      };
      a.$1 = function (a) {
        a = a;
        for (var b = 0; b < m.length; b++) {
          var c = m[b];
          a = c(a);
        }
        return a;
      };
      b.$2 = function (b, c) {
        c === void 0 && (c = !1);
        return t(
          {
            domain: a.$1(this.domain),
            fragment: this.fragment,
            fragmentSeparator: this.fragmentSeparator,
            isGeneric: this.isGenericProtocol,
            originalRawQuery: this.originalRawQuery,
            path: this.path,
            port: this.port,
            protocol: this.protocol,
            queryParams: this.queryParams,
            serializer: b,
            subdomain: this.subdomain,
            userInfo: "",
          },
          !1,
          c
        );
      };
      b.toStringRawQuery = function () {
        this.rawStringValue == null &&
          (this.rawStringValue = this.$2(c("PHPQuerySerializerNoEncoding")));
        return this.rawStringValue;
      };
      b.toString = function () {
        this.stringValue == null &&
          (this.stringValue = this.$2(this.serializer));
        return this.stringValue;
      };
      b.toStringPreserveQuery = function () {
        return this.$2(this.serializer, !0);
      };
      a.isValidUri = function (b) {
        var c = h.get(b);
        if (c != null) return !0;
        c = v(b);
        if (c.valid) {
          h.set(b, new a(c.components));
          return !0;
        }
        return !1;
      };
      return a;
    })();
    function a(a) {
      if (a instanceof x) return a;
      else return null;
    }
    function b(a) {
      m.push(a);
    }
    e = x.getUri;
    f = x.isValidUri;
    g.isSubdomainOfDomain = q;
    g.isConstUri = a;
    g.registerDomainFilter = b;
    g.getUri = e;
    g.isValidUri = f;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "routeBuilderUtils",
  [],
  function (a, b, c, d, e, f) {
    "use strict";
    function a(a) {
      a = a.split("/");
      return a
        .filter(function (a) {
          return a !== "";
        })
        .map(function (a) {
          var b = a.split(/{|}/);
          if (b.length < 3) return { isToken: !1, part: a };
          else {
            a = b[0];
            var c = b[1];
            b = b[2];
            var d = c[0] === "?",
              e = c[d ? 1 : 0] === "*";
            c = c.substring((d ? 1 : 0) + (e ? 1 : 0));
            return {
              isToken: !0,
              optional: d,
              catchAll: e,
              prefix: a,
              suffix: b,
              token: c,
            };
          }
        });
    }
    f.getPathParts = a;
  },
  66,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "jsRouteBuilder",
  ["ConstUriUtils", "FBLogger", "routeBuilderUtils"],
  function (a, b, c, d, e, f, g) {
    "use strict";
    var h = "#";
    function a(a, b, e, f, g) {
      g === void 0 && (g = !1);
      var i = d("routeBuilderUtils").getPathParts(a);
      function j(j) {
        try {
          var k = f != null ? babelHelpers["extends"]({}, f, j) : j,
            l = {};
          j = "";
          var m = !1;
          j = i.reduce(function (a, c) {
            if (!c.isToken) return a + "/" + c.part;
            else {
              var d,
                e = c.optional,
                f = c.prefix,
                g = c.suffix;
              c = c.token;
              if (e && m) return a;
              d = (d = k[c]) != null ? d : b[c];
              if (d == null && e) {
                m = !0;
                return a;
              }
              if (d == null)
                throw new Error("Missing required template parameter: " + c);
              if (d === "")
                throw new Error(
                  "Required template parameter is an empty string: " + c
                );
              l[c] = !0;
              return a + "/" + f + d + g;
            }
          }, "");
          a.slice(-1) === "/" && (j += "/");
          j === "" && (j = "/");
          var n = d("ConstUriUtils").getUri(j);
          for (var o in k) {
            var p = k[o];
            !l[o] &&
              p != null &&
              n != null &&
              (e != null && e.has(o)
                ? p !== !1 && (n = n.addQueryParam(o, null))
                : (n = n.addQueryParam(o, p)));
          }
          return [n, j];
        } catch (b) {
          p = b == null ? void 0 : b.message;
          o = c("FBLogger")("JSRouteBuilder")
            .blameToPreviousFrame()
            .blameToPreviousFrame();
          g && (o = o.blameToPreviousFrame());
          o.mustfix("Failed building URI for base path: %s message: %s", a, p);
          return [null, h];
        }
      }
      return {
        buildUri: function (a) {
          a = (a = j(a)[0]) != null ? a : d("ConstUriUtils").getUri(h);
          if (a == null)
            throw new Error("Not even the fallback URL parsed validly!");
          return a;
        },
        buildUriNullable: function (a) {
          return j(a)[0];
        },
        buildURLStringDEPRECATED: function (a) {
          a = j(a);
          var b = a[0];
          a = a[1];
          return (b = b == null ? void 0 : b.toString()) != null ? b : a;
        },
        buildURL: function (a) {
          a = j(a);
          var b = a[0];
          a = a[1];
          return (b = b == null ? void 0 : b.toString()) != null ? b : a;
        },
      };
    }
    g["default"] = a;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "XLynxAsyncCallbackControllerRouteBuilder",
  ["jsRouteBuilder"],
  function (a, b, c, d, e, f, g) {
    a = c("jsRouteBuilder")(
      "/si/linkclick/ajax_callback/",
      Object.freeze({}),
      void 0
    );
    b = a;
    g["default"] = b;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "FBLynxLogging",
  ["AsyncRequest", "ODS", "XLynxAsyncCallbackControllerRouteBuilder"],
  function (a, b, c, d, e, f, g) {
    "use strict";
    function a(a) {
      var b = c("XLynxAsyncCallbackControllerRouteBuilder").buildURL({});
      new (c("AsyncRequest"))(b)
        .setData({ lynx_uri: a })
        .setErrorHandler(function (a) {
          a = a.getError();
          d("ODS").bumpEntityKey(3861, "linkshim", "click_log.post.fail." + a);
        })
        .setTransportErrorHandler(function (a) {
          a = a.getError();
          d("ODS").bumpEntityKey(
            3861,
            "linkshim",
            "click_log.post.transport_fail." + a
          );
        })
        .send();
    }
    g.log = a;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "isLinkshimURI",
  ["isBulletinDotComURI", "isFacebookURI", "isMessengerDotComURI"],
  function (a, b, c, d, e, f, g) {
    "use strict";
    function a(a) {
      var b = a.getPath();
      return (b === "/l.php" ||
        b.indexOf("/si/ajax/l/") === 0 ||
        b.indexOf("/l/") === 0 ||
        b.indexOf("l/") === 0) &&
        (c("isFacebookURI")(a) ||
          c("isMessengerDotComURI")(a) ||
          c("isBulletinDotComURI")(a))
        ? !0
        : !1;
    }
    g["default"] = a;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "FBLynxBase",
  ["$", "FBLynxLogging", "LinkshimHandlerConfig", "URI", "isLinkshimURI"],
  function (a, b, c, d, e, f) {
    "use strict";
    var g;
    function h(a) {
      if (!b("isLinkshimURI")(a)) return null;
      a = a.getQueryData().u;
      return !a ? null : a;
    }
    var i = {
      logAsyncClick: function (a) {
        i.swapLinkWithUnshimmedLink(a);
        a = a.getAttribute("data-lynx-uri");
        if (!a) return;
        b("FBLynxLogging").log(a);
      },
      originReferrerPolicyClick: function (a) {
        var c = b("$")("meta_referrer");
        c.content = b("LinkshimHandlerConfig").switched_meta_referrer_policy;
        i.logAsyncClick(a);
        setTimeout(function () {
          c.content = b("LinkshimHandlerConfig").default_meta_referrer_policy;
        }, 100);
      },
      swapLinkWithUnshimmedLink: function (a) {
        var c = a.href,
          d = h(new (g || (g = b("URI")))(c));
        if (!d) return;
        a.setAttribute("data-lynx-uri", c);
        a.href = d;
      },
      revertSwapIfLynxURIPresent: function (a) {
        var b = a.getAttribute("data-lynx-uri");
        if (!b) return;
        a.removeAttribute("data-lynx-uri");
        a.href = b;
      },
    };
    e.exports = i;
  },
  null,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "FBLynx",
  ["Base64", "Event", "FBLynxBase", "LinkshimHandlerConfig", "Parent", "URI"],
  function (a, b, c, d, e, f) {
    "use strict";
    var g,
      h = (g || (g = b("URI"))).goURIOnWindow,
      i = {
        alreadySetup: !1,
        setupDelegation: function (a) {
          a === void 0 && (a = !1);
          if (!document.documentElement) return;
          if (document.body == null) {
            if (a) return;
            window.setTimeout(function () {
              i.setupDelegation(!0);
            }, 100);
            return;
          }
          if (i.alreadySetup) return;
          i.alreadySetup = !0;
          var c = function (a) {
            var c = i.getMaybeLynxLink(a.target);
            if (!c) return;
            var d = c[0];
            c = c[1];
            var e = c,
              f = new (g || (g = b("URI")))(c.href),
              j;
            if (
              b("LinkshimHandlerConfig").ghl_param_link_shim &&
              d !== "hover" &&
              c.dataset &&
              c.dataset.attributes
            ) {
              j = b("Base64").decodeObject(c.dataset.attributes);
              if (j && j.open_link) {
                var k;
                for (k in j) k !== "open_link" && f.addQueryData(k, j[k]);
                k = c.cloneNode(!0);
                k.href = f.toString();
                e = k;
              }
            }
            switch (d) {
              case "async":
              case "asynclazy":
                b("FBLynxBase").logAsyncClick(e);
                break;
              case "origin":
                b("FBLynxBase").originReferrerPolicyClick(e);
                break;
              case "hover":
                i.hoverClick(e);
                break;
            }
            b("LinkshimHandlerConfig").ghl_param_link_shim &&
              d !== "hover" &&
              j &&
              j.open_link &&
              (a.preventDefault(), h(f, window.open("", e.target), !0));
          };
          b("Event").listen(document.body, "click", c);
          b("LinkshimHandlerConfig").middle_click_requires_event &&
            b("Event").listen(document.body, "mouseup", function (a) {
              a.button == 1 && c(a);
            });
          b("Event").listen(document.body, "mouseover", function (a) {
            a = i.getMaybeLynxLink(a.target);
            if (!a) return;
            var b = a[0];
            a = a[1];
            switch (b) {
              case "async":
              case "asynclazy":
              case "origin":
              case "hover":
                i.mouseover(a);
                break;
            }
          });
          b("Event").listen(document.body, "contextmenu", function (a) {
            a = i.getMaybeLynxLink(a.target);
            if (!a) return;
            var b = a[0];
            a = a[1];
            switch (b) {
              case "async":
              case "hover":
              case "origin":
                i.contextmenu(a);
                break;
              case "asynclazy":
                break;
            }
          });
        },
        getMaybeLynxLink: function (a) {
          a = b("Parent").byAttribute(a, "data-lynx-mode");
          if (a instanceof HTMLAnchorElement) {
            var c = a.getAttribute("data-lynx-mode");
            switch (c) {
              case "async":
              case "asynclazy":
              case "hover":
              case "origin":
                return [c, a];
              default:
                return null;
            }
          }
          return null;
        },
        hoverClick: function (a) {
          b("FBLynxBase").revertSwapIfLynxURIPresent(a);
        },
        mouseover: function (a) {
          b("FBLynxBase").swapLinkWithUnshimmedLink(a);
        },
        contextmenu: function (a) {
          b("FBLynxBase").revertSwapIfLynxURIPresent(a);
        },
      };
    e.exports = i;
  },
  null,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "FBIDCheck",
  [],
  function (a, b, c, d, e, f) {
    "use strict";
    var g = /^[1-9]\d*$/;
    function a(a) {
      a = a;
      if (a == null || (typeof a === "string" && !g.test(a))) return !1;
      a = parseInt(a, 10);
      return !a
        ? !1
        : (a > 0 && a < 22e8) ||
            (a >= 1e14 && a <= 100099999989999) ||
            (a >= 89e12 && a <= 89999999999999) ||
            (a >= 6000001e7 && a <= 60000019999999);
    }
    f.isUser_deprecated = a;
  },
  66,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "FocusEvent",
  ["Event", "Run", "ge", "getOrCreateDOMID"],
  function (a, b, c, d, e, f, g) {
    "use strict";
    var h = {},
      i = !1;
    function j(a, b) {
      if (h[a]) {
        b = h[a].indexOf(b);
        b >= 0 && h[a].splice(b, 1);
        h[a].length === 0 && delete h[a];
      }
    }
    function k(a) {
      var b = a.getTarget();
      if (h[b.id] && h[b.id].length > 0) {
        var c = a.type === "focusin" || a.type === "focus";
        h[b.id].forEach(function (a) {
          a(c);
        });
      }
    }
    function l() {
      if (i) return;
      c("Event").listen(document.documentElement, "focusout", k);
      c("Event").listen(document.documentElement, "focusin", k);
      i = !0;
    }
    function a(a, b, e) {
      l();
      var f = c("getOrCreateDOMID")(a);
      h[f] || (h[f] = []);
      h[f].push(b);
      var g = !1;
      function i() {
        g || (j(f, b), k && (k.remove(), (k = null)), (g = !0));
      }
      var k =
        (e == null ? void 0 : e.runtime_site_is_comet) !== !0
          ? d("Run").onLeave(function () {
              c("ge")(f) || i();
            })
          : null;
      return {
        remove: function () {
          i();
        },
      };
    }
    g.listen = a;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "isStringNullOrEmpty",
  [],
  function (a, b, c, d, e, f) {
    "use strict";
    function a(a) {
      return a == null || a === "";
    }
    f["default"] = a;
  },
  66,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "tooltipPropsFor",
  [],
  function (a, b, c, d, e, f) {
    "use strict";
    function a(a, b, c) {
      if (!a) return {};
      a = { "data-tooltip-content": a, "data-hover": "tooltip" };
      b && (a["data-tooltip-position"] = b);
      c && (a["data-tooltip-alignh"] = c);
      return a;
    }
    f["default"] = a;
  },
  66,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "TooltipData",
  [
    "DOM",
    "DataStore",
    "FBLogger",
    "URI",
    "getElementText",
    "ifRequired",
    "isStringNullOrEmpty",
    "isTextNode",
    "killswitch",
    "tooltipPropsFor",
  ],
  function (a, b, c, d, e, f) {
    var g;
    function h(a) {
      var c = a.getAttribute("data-tooltip-delay");
      c = c ? parseInt(c, 10) || 1e3 : 0;
      if (b("killswitch")("TOOLTIP_SEPARATE_DATASTORE_AND_ATTRIBUTE_CONTENT"))
        return babelHelpers["extends"](
          {
            className: a.getAttribute("data-tooltip-root-class"),
            content: a.getAttribute("data-tooltip-content"),
            delay: c,
            position: a.getAttribute("data-tooltip-position") || "above",
            alignH: a.getAttribute("data-tooltip-alignh") || "left",
            offsetY: a.getAttribute("data-tooltip-offsety") || 0,
            suppress: !1,
            overflowDisplay:
              a.getAttribute("data-tooltip-display") === "overflow",
            persistOnClick: a.getAttribute("data-pitloot-persistonclick"),
            textDirection: a.getAttribute("data-tooltip-text-direction"),
          },
          b("DataStore").get(a, "tooltip")
        );
      else {
        var d;
        d = (d = b("DataStore").get(a, "tooltip")) != null ? d : {};
        var e = d.content;
        d = babelHelpers.objectWithoutPropertiesLoose(d, ["content"]);
        var f = a.getAttribute("data-tooltip-content");
        !b("isStringNullOrEmpty")(e) &&
          !b("isStringNullOrEmpty")(f) &&
          b("FBLogger")("tooltip").warn(
            'Getting DataStore tooltip content on an element that has both a "data-tooltip-content" attribute value (set to %s) and a value coming from the DataStore',
            a.getAttribute("data-tooltip-content")
          );
        return babelHelpers["extends"](
          {
            className: a.getAttribute("data-tooltip-root-class"),
            delay: c,
            position: a.getAttribute("data-tooltip-position") || "above",
            alignH: a.getAttribute("data-tooltip-alignh") || "left",
            offsetY: a.getAttribute("data-tooltip-offsety") || 0,
            suppress: !1,
            overflowDisplay:
              a.getAttribute("data-tooltip-display") === "overflow",
            persistOnClick: a.getAttribute("data-pitloot-persistonclick"),
            textDirection: a.getAttribute("data-tooltip-text-direction"),
            content: (a = (c = f) != null ? c : e) != null ? a : null,
          },
          d
        );
      }
    }
    function i(a, c) {
      var d = h(a);
      if (b("killswitch")("TOOLTIP_SEPARATE_DATASTORE_AND_ATTRIBUTE_CONTENT"))
        b("DataStore").set(a, "tooltip", {
          content: c.content || d.content,
          position: c.position || d.position,
          alignH: c.alignH || d.alignH,
          suppress: c.suppress !== void 0 ? c.suppress : d.suppress,
          overflowDisplay: c.overflowDisplay || d.overflowDisplay,
          persistOnClick: c.persistOnClick || d.persistOnClick,
        });
      else {
        !b("isStringNullOrEmpty")(c.content) &&
          !b("isStringNullOrEmpty")(a.getAttribute("data-tooltip-content")) &&
          b("FBLogger")("tooltip").warn(
            'Setting DataStore tooltip content on an element that already has the "data-tooltip-content" attribute (set to %s) is invalid',
            a.getAttribute("data-tooltip-content")
          );
        b("DataStore").set(a, "tooltip", {
          content:
            c.content ||
            ((a = b("DataStore").get(a, "tooltip")) != null ? a : {}).content,
          position: c.position || d.position,
          alignH: c.alignH || d.alignH,
          suppress: c.suppress !== void 0 ? c.suppress : d.suppress,
          overflowDisplay: c.overflowDisplay || d.overflowDisplay,
          persistOnClick: c.persistOnClick || d.persistOnClick,
        });
      }
    }
    function j(a, b) {
      i(a, b), a.setAttribute("data-hover", "tooltip");
    }
    function k(a, b) {}
    var l = {
      remove: function (a, c) {
        c = c === void 0 ? {} : c;
        c = c.onlyCleanupDataStore;
        c = c === void 0 ? !1 : c;
        b("DataStore").remove(a, "tooltip");
        c ||
          (a.removeAttribute("data-hover"),
          a.removeAttribute("data-tooltip-position"),
          a.removeAttribute("data-tooltip-alignh"),
          b("ifRequired")("Tooltip", function (b) {
            b.isActive(a) && b.hide();
          }));
      },
      set: function (a, c, d, e) {
        k(a, c);
        if (c instanceof (g || (g = b("URI"))))
          a.setAttribute("data-tooltip-uri", c),
            b("ifRequired")("Tooltip", function (b) {
              b.isActive(a) && b.fetchIfNecessary(a);
            });
        else if (
          b("killswitch")("TOOLTIP_SEPARATE_DATASTORE_AND_ATTRIBUTE_CONTENT")
        ) {
          var f = l._store({ context: a, content: c, position: d, alignH: e });
          typeof f.content !== "string"
            ? a.setAttribute(
                "data-tooltip-content",
                b("getElementText")(f.content)
              )
            : a.setAttribute("data-tooltip-content", f.content);
          l.refreshIfActive(a);
        } else
          a.removeAttribute("data-tooltip-content"),
            l._store({ context: a, content: c, position: d, alignH: e }),
            l.refreshIfActive(a);
      },
      refreshIfActive: function (a) {
        b("ifRequired")("Tooltip", function (b) {
          b.isActive(a) && b.show(a);
        });
      },
      _store: function (a) {
        var c = a.context,
          d = a.content,
          e = a.position;
        a = a.alignH;
        k(c, d);
        b("isTextNode")(d) && (d = b("getElementText")(d));
        var f = !1;
        typeof d !== "string"
          ? (d = b("DOM").create("div", {}, d))
          : (f = d === "");
        a = { alignH: a, content: d, position: e, suppress: f };
        j(c, a);
        return a;
      },
      propsFor: b("tooltipPropsFor"),
      enableDisplayOnOverflow: function (a) {
        a.removeAttribute("data-tooltip-display"),
          j(a, { overflowDisplay: !0 });
      },
      enablePersistOnClick: function (a) {
        a.removeAttribute("data-pitloot-persistOnClick"),
          j(a, { persistOnClick: !0 });
      },
      suppress: function (a, b) {
        i(a, { suppress: b });
      },
      _get: h,
    };
    e.exports = l;
  },
  null,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "Focus",
  [
    "cx",
    "CSS",
    "Event",
    "FocusEvent",
    "KeyStatus",
    "TooltipData",
    "ifRequired",
  ],
  function (a, b, c, d, e, f, g, h) {
    function a(a, b) {
      b === void 0 && (b = !1);
      if (a) {
        var e = c("ifRequired")(
          "VirtualCursorStatus",
          function (a) {
            return a.isVirtualCursorTriggered();
          },
          function () {
            return !1;
          }
        );
        b || d("KeyStatus").isKeyDown() || e ? k(a) : i(a);
      }
    }
    function i(a) {
      if (a) {
        d("CSS").addClass(a, "_5f0v");
        var b = c("Event").listen(a, "blur", function () {
          a && d("CSS").removeClass(a, "_5f0v"), b.remove();
        });
        d("TooltipData").suppress(a, !0);
        k(a);
        d("TooltipData").suppress(a, !1);
      }
    }
    function b(a, b) {
      d("CSS").addClass(a, "_5f0v");
      return d("FocusEvent").listen(a, function () {
        for (var c = arguments.length, d = new Array(c), e = 0; e < c; e++)
          d[e] = arguments[e];
        return j.apply(void 0, [a, b].concat(d));
      });
    }
    function j(a, b, e) {
      d("CSS").addClass(a, "_5f0v");
      a = c("ifRequired")(
        "FocusRing",
        function (a) {
          return a.usingKeyboardNavigation();
        },
        function () {
          return !0;
        }
      );
      e = e && a;
      d("CSS").conditionClass(b, "_3oxt", e);
      d("CSS").conditionClass(b, "_16jm", e);
    }
    function k(a) {
      try {
        (a.tabIndex = a.tabIndex), a.focus();
      } catch (a) {}
    }
    g.set = a;
    g.setWithoutOutline = i;
    g.relocate = b;
    g.performRelocation = j;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "debounceCore",
  ["TimeSlice"],
  function (a, b, c, d, e, f, g) {
    function a(a, b, d, e, f, g) {
      d === void 0 && (d = null);
      e === void 0 && (e = setTimeout);
      f === void 0 && (f = clearTimeout);
      g === void 0 && (g = !1);
      var h,
        i = !0;
      function j() {
        for (var k = arguments.length, l = new Array(k), m = 0; m < k; m++)
          l[m] = arguments[m];
        var n;
        if (g) {
          n = c("TimeSlice").guard(function () {
            (i = !0), (h = null);
          }, "debounceCore");
          if (!i) {
            f(h);
            h = e(n, b);
            return;
          }
          i = !1;
          a.apply(d, l);
        } else
          j.reset(),
            (n = c("TimeSlice").guard(function () {
              (h = null), a.apply(d, l);
            }, "debounceCore"));
        n.__SMmeta = a.__SMmeta;
        h = e(n, b);
      }
      j.reset = function () {
        f(h), (h = null), (i = !0);
      };
      j.isPending = function () {
        return h != null;
      };
      return j;
    }
    g["default"] = a;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "debounce",
  ["clearTimeout", "debounceCore", "setTimeout"],
  function (a, b, c, d, e, f, g) {
    function a(a, b, d, e, f) {
      b === void 0 && (b = 100);
      var g = function (a, b, d) {
        return c("setTimeout")(a, b, d, !e);
      };
      return c("debounceCore")(a, b, d, g, c("clearTimeout"), f);
    }
    g["default"] = a;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "debounceAcrossTransitions",
  ["debounce"],
  function (a, b, c, d, e, f, g) {
    function a(a, b, d) {
      return c("debounce")(a, b, d, !0);
    }
    g["default"] = a;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "getImageSourceURLFromImageish",
  [],
  function (a, b, c, d, e, f) {
    "use strict";
    function a(a) {
      if (typeof a === "string") return a;
      return a != null &&
        typeof a === "object" &&
        !a.sprited &&
        a.uri &&
        typeof a.uri === "string"
        ? a.uri
        : "";
    }
    f["default"] = a;
  },
  66,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "isEnterpriseURI",
  [],
  function (a, b, c, d, e, f) {
    function a(a) {
      if (a.isEmpty() && a.toString() !== "#") return !1;
      if (!a.getDomain() && !a.getProtocol()) return !1;
      return a.getProtocol() !== "https"
        ? !1
        : a.getDomain().includes("facebookenterprise.com") ||
            a.getDomain().includes("metaenterprise.com");
    }
    f["default"] = a;
  },
  66,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "isInstagramURI",
  [],
  function (a, b, c, d, e, f) {
    var g = null;
    function a(a) {
      if (a.isEmpty() && a.toString() !== "#") return !1;
      if (!a.getDomain() && !a.getProtocol()) return !1;
      if (a.getProtocol() !== "https") return !1;
      g || (g = new RegExp("(^|\\.)instagram\\.com$", "i"));
      return g.test(a.getDomain());
    }
    f["default"] = a;
  },
  66,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "isRoomsURI",
  [],
  function (a, b, c, d, e, f) {
    var g = new RegExp("(^|\\.)msngr\\.com$", "i"),
      h = new RegExp("(^|\\.)fbaud\\.io$", "i"),
      i = new RegExp("(^|\\.)fb\\.audio$", "i"),
      j = ["https"];
    function a(a) {
      if (a.isEmpty() && a.toString() !== "#") return !1;
      return !a.getDomain() && !a.getProtocol()
        ? !1
        : j.indexOf(a.getProtocol()) !== -1 &&
            (g.test(a.getDomain()) ||
              h.test(a.getDomain()) ||
              i.test(a.getDomain()));
    }
    f["default"] = a;
  },
  66,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "isTrustedCMSContentURI",
  [],
  function (a, b, c, d, e, f) {
    function a(a) {
      return !0;
    }
    f["default"] = a;
  },
  66,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "isWhatsAppURI",
  [],
  function (a, b, c, d, e, f) {
    var g = new RegExp("(^|\\.)whatsapp\\.com$", "i");
    function a(a) {
      if (a.isEmpty() && a.toString() !== "#") return !1;
      if (!a.getDomain() && !a.getProtocol()) return !1;
      return a.getProtocol() !== "https" ? !1 : g.test(a.getDomain());
    }
    f["default"] = a;
  },
  66,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "isWorkAccountsURI",
  [],
  function (a, b, c, d, e, f) {
    "use strict";
    var g = /(work|work-test)\.facebook\.com|(^|\.)work\.meta\.com$/i;
    function a(a) {
      return a.getProtocol() === "https" && h(a.getDomain());
    }
    function h(a) {
      return g.test(a);
    }
    f.isWorkAccountsURI = a;
    f.isWorkAccountsDomain = h;
  },
  66,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "isTrustedDestination",
  [
    "LinkshimHandlerConfig",
    "isBulletinDotComURI",
    "isEnterpriseURI",
    "isExpressWifiDotComURI",
    "isFacebookURI",
    "isInstagramURI",
    "isInternalFBURI",
    "isOculusDotComURI",
    "isRoomsURI",
    "isTrustedCMSContentURI",
    "isWhatsAppURI",
    "isWorkAccountsURI",
    "isWorkplaceDotComURI",
  ],
  function (a, b, c, d, e, f, g) {
    "use strict";
    function h() {
      return /(^|\.)oculus\.com$/.test(
        c("LinkshimHandlerConfig").current_domain
      );
    }
    function i() {
      return /(^|\.)expresswifi\.com$/.test(
        c("LinkshimHandlerConfig").current_domain
      );
    }
    function j() {
      return /(^|\.)workplace\.com$/.test(
        c("LinkshimHandlerConfig").current_domain
      );
    }
    function k() {
      return d("isWorkAccountsURI").isWorkAccountsDomain(
        c("LinkshimHandlerConfig").current_domain
      );
    }
    function l() {
      return /(^|\.)accountscenter\.meta\.com$/.test(
        c("LinkshimHandlerConfig").current_domain
      );
    }
    function m() {
      return /(^|\.)(facebook|meta)enterprise\.com$/.test(
        c("LinkshimHandlerConfig").current_domain
      );
    }
    function n() {
      return /(^|\.)bulletin\.com$/.test(
        c("LinkshimHandlerConfig").current_domain
      );
    }
    function o() {
      return /(^|\.)www\.meta\.com$/.test(
        c("LinkshimHandlerConfig").current_domain
      );
    }
    function p() {
      return /^store(\..+)?\.facebook\.com$/.test(
        c("LinkshimHandlerConfig").current_domain
      );
    }
    function q() {
      return /(^|\.)about\.meta\.com$|^about(\..+)?\.facebook\.com$/.test(
        c("LinkshimHandlerConfig").current_domain
      );
    }
    function r() {
      return /(^|\.)internalfb\.com$/.test(
        c("LinkshimHandlerConfig").current_domain
      );
    }
    function s() {
      return /(^|\.)instagram\.com$/.test(
        c("LinkshimHandlerConfig").current_domain
      );
    }
    function t() {
      return /(^|\.)whatsapp\.com$/.test(
        c("LinkshimHandlerConfig").current_domain
      );
    }
    function u(a) {
      return c("isFacebookURI")(a);
    }
    function v(a) {
      return c("isWorkplaceDotComURI")(a);
    }
    function a(a) {
      if (
        c("isRoomsURI")(a) &&
        c("LinkshimHandlerConfig").is_mobile_device === !0
      )
        return !0;
      if (j()) return v(a);
      if (r()) return c("isInternalFBURI")(a) || u(a);
      if (h()) return c("isOculusDotComURI")(a);
      if (i()) return c("isExpressWifiDotComURI")(a);
      if (s()) return c("isInstagramURI")(a);
      if (t()) return c("isWhatsAppURI")(a);
      if (k()) return d("isWorkAccountsURI").isWorkAccountsURI(a) || u(a);
      if (l()) return u(a) || c("isInstagramURI")(a);
      if (m()) return c("isEnterpriseURI")(a);
      if (n()) return c("isBulletinDotComURI")(a);
      return p() || o() || q() ? c("isTrustedCMSContentURI")(a) : u(a);
    }
    g["default"] = a;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "keyMirror",
  ["unrecoverableViolation"],
  function (a, b, c, d, e, f, g) {
    "use strict";
    function a(a) {
      var b = {};
      if (!(a instanceof Object && !Array.isArray(a)))
        throw c("unrecoverableViolation")(
          "keyMirror(...): Argument must be an object.",
          "comet_infra"
        );
      for (var d in a) {
        if (!Object.prototype.hasOwnProperty.call(a, d)) continue;
        b[d] = d;
      }
      return b;
    }
    g["default"] = a;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "SubscriptionsHandler",
  ["invariant"],
  function (a, b, c, d, e, f, g, h) {
    "use strict";
    function i(a) {
      return a.remove || a.reset || a.unsubscribe || a.cancel || a.dispose;
    }
    function j(a) {
      i(a).call(a);
    }
    a = (function () {
      function a() {
        this.$1 = [];
      }
      var b = a.prototype;
      b.addSubscriptions = function () {
        for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++)
          b[c] = arguments[c];
        b.every(i) || h(0, 3659);
        this.$1 != null ? (this.$1 = this.$1.concat(b)) : b.forEach(j);
      };
      b.engage = function () {
        this.$1 == null && (this.$1 = []);
      };
      b.release = function () {
        this.$1 != null && (this.$1.forEach(j), (this.$1 = null));
      };
      b.releaseOne = function (a) {
        var b = this.$1;
        if (b == null) return;
        var c = b.indexOf(a);
        c !== -1 && (j(a), b.splice(c, 1), b.length === 0 && (this.$1 = null));
      };
      return a;
    })();
    g["default"] = a;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "throttle",
  [
    "TimeSlice",
    "TimeSliceInteractionSV",
    "setTimeout",
    "setTimeoutAcrossTransitions",
  ],
  function (a, b, c, d, e, f, g) {
    function a(a, b, d) {
      return h(a, b, d, c("setTimeout"), !1);
    }
    Object.assign(a, {
      acrossTransitions: function (a, b, d) {
        return h(a, b, d, c("setTimeoutAcrossTransitions"), !1);
      },
      withBlocking: function (a, b, d) {
        return h(a, b, d, c("setTimeout"), !0);
      },
      acrossTransitionsWithBlocking: function (a, b, d) {
        return h(a, b, d, c("setTimeoutAcrossTransitions"), !0);
      },
    });
    function h(a, b, d, e, f) {
      var g = b == null ? 100 : b,
        h,
        i = null,
        j = 0,
        k = null,
        l = [],
        m = c("TimeSlice").guard(
          function () {
            j = Date.now();
            if (i) {
              var b = function (b) {
                  a.apply(h, b);
                }.bind(null, i),
                c = l.length;
              while (--c >= 0) b = l[c].bind(null, b);
              l = [];
              b();
              i = null;
              k = e(m, g);
            } else k = null;
          },
          "throttle_" + g + "_ms",
          {
            propagationType: c("TimeSlice").PropagationType.EXECUTION,
            registerCallStack: !0,
          }
        );
      m.__SMmeta = a.__SMmeta;
      return function () {
        c("TimeSliceInteractionSV").ref_counting_fix &&
          l.push(
            c("TimeSlice").getGuardedContinuation("throttleWithContinuation")
          );
        for (var a = arguments.length, b = new Array(a), n = 0; n < a; n++)
          b[n] = arguments[n];
        i = b;
        h = this;
        d !== void 0 && (h = d);
        (k === null || Date.now() - j > g) && (f === !0 ? m() : (k = e(m, 0)));
      };
    }
    b = a;
    g["default"] = b;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
__d(
  "useCurrentRouteBuilder",
  [
    "CometRouteParams",
    "ConstUriUtils",
    "jsRouteBuilder",
    "react",
    "useCurrentRoute",
  ],
  function (a, b, c, d, e, f, g) {
    "use strict";
    var h = d("react").useMemo;
    function a(a) {
      var b,
        e = d("CometRouteParams").useRouteParams();
      b = (b = c("useCurrentRoute")()) != null ? b : {};
      var f = b.routePath;
      b = b.url;
      b =
        b != null
          ? (b = d("ConstUriUtils").getUri(b)) == null
            ? void 0
            : b.getPath()
          : null;
      var g = (a == null ? void 0 : a.useUrlPath) === !0 ? b : f;
      return h(
        function () {
          return g == null
            ? null
            : c("jsRouteBuilder")(g, Object.freeze({}), new Set(), e);
        },
        [g, e]
      );
    }
    g["default"] = a;
  },
  98,
  typeof self !== "undefined" && self.document && self.document.currentScript
);
